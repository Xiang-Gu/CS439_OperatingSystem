#include "libc.h"

int main(int argc, char** argv) {
    puts("*** 10 hello, user"); // write this string to the standard output (the console)
    char* ptr = malloc(100);    // dynamically get a 100-byte memory in the heap
    memcpy(ptr,"*** 20 looking normal\n",22);  // write this 22-byte-long string to the beginning of the chuck of memory just allocated from the heap
    int togo = 22;
    while (togo > 0) {
        int cnt = write(1,ptr,22); // now output that 22-byte-long string
        togo -= cnt;
    }
    return 0;
}
