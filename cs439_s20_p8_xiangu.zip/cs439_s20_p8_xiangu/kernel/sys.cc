#include "sys.h"
#include "stdint.h"
#include "idt.h"
#include "debug.h"
#include "machine.h"

// kernel-side functions used to handle each system call we need to provide
int exitHandler(uint32_t*);
int writeHandler(uint32_t*);

extern "C" int sysHandler(uint32_t eax, uint32_t *frame) {
	// get the user stack pointer, which stores all the arguments passed to the system call
	uint32_t* userEsp = (uint32_t*) frame[3];

	switch(eax) {
		case 0:
			return exitHandler(userEsp);
		case 1:
			return writeHandler(userEsp);
		default:
			Debug::panic("Unknown syscall type!");
			return -1;
	}
}

// handles exit(int rc) syscall
int exitHandler(uint32_t* userEsp) {
	int rc = userEsp[1];
	Debug::shutdown();
	return rc;
}

// handles write(int fd, void* buf, size_t nbytes) syscall
int writeHandler(uint32_t* userEsp) {
	// an first attemp: always write to standard output
	int fd = (int) userEsp[1];
	if (fd != 1) {
		Debug::printf("input fd = %d in syscall write.\n", fd);
		Debug::panic("our current write syscall can only write to standard output fd = 1");
	}
	char* buf = (char*) userEsp[2];
	size_t nbyte = (size_t) userEsp[3];
	for (size_t i = 0; i < nbyte; ++i) {
		Debug::printf("%c", buf[i]);
	}
	return nbyte;
}


void SYS::init(void) {
    IDT::trap(48,(uint32_t)sysHandler_,3);
}
