#include "libc.h"

void one(int fd) {
    printf("*** fd = %d\n",fd);
    printf("*** len = %d\n",len(fd));

    cp(fd,2);
}

int main(int argc, char** argv) {
	int fd1 = open("/etc/data.txt",0);
	int fd2 = open("/etc/panic.txt",0);
	if (fd1 == fd2)
		printf("*** two open system calls return same file descriptor.\n");

	int id = fork();
	if (id < 0) {
		printf("*** fork has failed.\n");
	} else if (id == 0) {
		// child, fork again
		exit(0xC02);
	} else {
		uint32_t status;
		wait(id, &status);
		if (status != 0xC02) 
			printf("*** wait and exit does not work well b/t parent and child.\n");
	}

	printf("*** you passed the test.\n");
	shutdown();
	return 0;
}
