#ifndef _FDT_H_
#define _FDT_H_

#include "file.h"

class FileDescriptorTable {
public:
	static const uint32_t MAX_RESOURCE_NUMBER = 300;

	File* FDT[FileDescriptorTable::MAX_RESOURCE_NUMBER];

	FileDescriptorTable() {
		FDT[0] = new StdIn();
		FDT[1] = new StdOut();
		FDT[2] = new StdErr();

		for (uint32_t i = 3; i < FileDescriptorTable::MAX_RESOURCE_NUMBER; ++i) {
			FDT[i] = nullptr;
		}
	}

	~FileDescriptorTable() {
		// TODO: 1. Iterate over FDT and determine whether
		//          to delete the future or not. (how?)

	}

	// iterate over FDT and return the first nullptr position
	int nextEmptyDescriptor() {
		for (uint32_t i = 0; i < FileDescriptorTable::MAX_RESOURCE_NUMBER; ++i) {
			if (FDT[i] == nullptr) {
				return i;
			}
		}
		Debug::printf("| FDT is full!");
		return -1;
	}

	// iterate over FDT backwards and return the first nullptr position
	int nextEmptyDescriptorReversed() {
		for (uint32_t i = FileDescriptorTable::MAX_RESOURCE_NUMBER - 1; i >= 0; --i) {
			if (FDT[i] == nullptr) {
				return i;
			}
		}
		Debug::printf("| FDT is full!");
		return -1;
	}

	// get File pointer at index descriptor
	File* get(uint32_t descriptor) {
		return FDT[descriptor];
	}

	// close the resource at index descriptor
	void closeResourceAt(uint32_t descriptor) {
		delete FDT[descriptor];
		FDT[descriptor] = nullptr;
	}

	// set the resource at index descriptor to v
	void set(uint32_t descriptor, File* v) {
		FDT[descriptor] = v;
	}
};



#endif