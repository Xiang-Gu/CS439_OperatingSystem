#ifndef _FILE_H_
#define _FILE_H_

#include "stdint.h"
#include "bobfs.h"
#include "semaphore.h"
#include "debug.h"
#include "future.h"

extern BobFS* fileSystem;
// extern OpenNodes openNodes;

// // an array that maps from index = inumber to value = Node*
// class OpenNodes {
// 	BobFS* fs;
// 	Node* mapping[BobFS::BLOCK_SIZE * 8];
// 	Mutex locks[BobFS::BLOCK_SIZE * 8];

// public:
// 	OpenNodes(BobFS* fs) : fs(fs) {
// 		for (int i = 0; i < BobFS::BLOCK_SIZE * 8; ++i)
// 			mapping[i] = nullptr;
// 	}
// 	~OpenNodes() {
// 		// TODO: 1. Iterate over mapping and determine whether
// 		//          to delete the future or not. (how?)
// 	}

// 	Node* get(uint32_t inumber) {
// 		locks[inumber].lock();
// 		if (mapping[inumber] == nullptr) {
// 			mapping[inumber] = new Node(fs, inumber);	
// 		}
// 		locks[inumber].unlock();
// 		return mapping[inumber];
// 	}
// };


// Here "File" is overloaded to mean any resources a process can own
// E.g. A process can have open files, semaphores, and child processes.
// All those three things will be derived classes from this File base class.
class File {
public:

    virtual ~File() {
    	// TODO: think carefully what needs to be deleted in destructor.
    	//       This destructor will be invoked when resource at FDT is closed.
    }

    virtual File* clone() {return nullptr;}
    // functionalities of OpenFile objects
    virtual bool isFile() {return false;}
    virtual bool isDirectory() {return false;}
    virtual off_t size() {return -1;}
    virtual off_t seek(off_t offset) {return -1;}
    virtual ssize_t read(void* buf, size_t size) {return -1;}
    virtual ssize_t write(void* buf, size_t size) {return -1;}

    // functionalities of Sem objects
    virtual int down() {return -1;}
    virtual int up() {return -1;}

    // functionalities of ChildProc objects
    virtual ssize_t waitToFinish(uint32_t* status) {return -1;}


};

class OpenFile : public File {
	Node* inode;
	uint32_t offset;

public:
	// OpenFile(uint32_t inumber) : offset(0) {
	// 	inode = openNode.get(fileSystem, inumber);
	// }

	OpenFile(Node* n, uint32_t offset = 0) : inode(n), offset(offset) {}


	~OpenFile() {
		// TODO: 1. add a openCount field in Node class that represents how many
		//          time this inode has been opened in processes.
		//       2. decrement openCount of inode by 1 because we're closing it
		//       3. delete the Node object when openCount == 0.
	}

    virtual OpenFile* clone() override { return new OpenFile(inode, offset); }

	virtual bool isFile() override { return inode -> isFile(); }

    virtual bool isDirectory() override { return inode -> isDirectory(); }

    virtual off_t size() override { return inode -> getSize(); }

    virtual off_t seek(off_t offset) override {
    	this -> offset = offset;
    	return offset;
    }

    virtual ssize_t read(void* buf, size_t size) override {
    	int32_t n = inode -> read(offset, buf, size);
    	if (n < 0) 
    		return n;
    	offset += n;
    	return n;
    }

    virtual ssize_t write(void* buf, size_t size) override {
    	int32_t n = inode -> write(offset, buf, size);
    	if (n < 0)
    		return n;
    	offset += n;
    	return n;
    }
};

class StdIn : public File {
public:
    StdIn() = default;
    ~StdIn() = default;

    virtual StdIn* clone() override { return new StdIn(); }

    virtual bool isFile() override { return true; }

    // unfortuantely, our implementation does not support reading from stdin...
    virtual ssize_t read(void* buf, size_t size) override {
        return -1;
    }
};

class StdOut : public File {
public:
    StdOut() = default;
    ~StdOut() = default;

    virtual StdOut* clone() override { return new StdOut(); }

    virtual bool isFile() override { return true; }

    virtual ssize_t write(void* buf, size_t size) override {
        for (uint32_t i = 0; i < size; ++i){
            Debug::printf("%c", ((char*) buf)[i]);
        }
        return size;
    }
};

class StdErr : public File {
public:
    StdErr() = default;
    ~StdErr() = default;

    virtual StdErr* clone() override { return new StdErr(); }

    virtual bool isFile() override { return true; }

    // our stderr will, again, write to the console as stdout
    virtual ssize_t write(void* buf, size_t size) override {
        for (uint32_t i = 0; i < size; ++i){
            Debug::printf("%c", ((char*) buf)[i]);
        }
        return size;
    }
};

class Sem : public File {
	Semaphore sem;

public:
	Sem(const uint32_t count) : sem(count) {}

    virtual Sem* clone() override { return this; }

	virtual int down() override {sem.down(); return 0;}

    virtual int up() override {sem.up(); return 0;}
};


class ChildProc : public File {
public:
	Future<int> hasFinished; // set when the child procee called exit(rc)

	ChildProc() {
		// TODO: think about how to write the constructor
		//       1. need a new ThreadImpl that me points to
		//       2. this new ThreadImpl should have code into that
		//          calls switchToUser with entry
	}
	
	// see whether the child process has finished or not by looking at
	// the Future, because the Future is the agreed-upon place for the 
	// child to inform the parent. If the value in Future is not ready,
	// then the parent will block itself and wait until it's ready.
	virtual ssize_t waitToFinish(uint32_t* status) override {
		*status = hasFinished.get();
		return 0;
	}
};


#endif
