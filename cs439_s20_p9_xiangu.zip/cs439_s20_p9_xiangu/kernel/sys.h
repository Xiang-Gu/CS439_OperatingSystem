#ifndef _SYS_H_
#define _SYS_H_

class SYS {
public:
    static void init(void);
};

#endif
