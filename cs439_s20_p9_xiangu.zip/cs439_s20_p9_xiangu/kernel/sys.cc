#include "sys.h"
#include "stdint.h"
#include "idt.h"
#include "debug.h"
#include "machine.h"
#include "bobfs.h"
#include "threads.h"
#include "fdt.h"
#include "file.h"
#include "vmm.h"
#include "elf.h"
#include "string.h"

extern BobFS* fileSystem;

// handles exit(int rc) syscall
int exitHandler(uint32_t* userEsp) {
	int rc = userEsp[1];
	Future<int>* hasFinished = active() -> hasFinished;
	if (hasFinished == nullptr) {
		Debug::printf("init is exiting...\n");
	} else {
		// informing my parent that I'm finished
		hasFinished -> set(rc);
	}
	stop();
	return 0;
}

// handles int write(int fd, void* buf, size_t nbytes) syscall
int writeHandler(uint32_t* userEsp) {
	int fd = (int) userEsp[1];
	char* buf = (char*) userEsp[2];
	size_t nbytes = (size_t) userEsp[3];

	if (fd < 0) return -1; // invalid descriptor

	File* file = active() -> fileDescriptorTable -> get(fd);
	if (file == nullptr) return -1; // trying to write to a file that does not exist

	return file -> write(buf, nbytes); // polymorphism will return -1 if file actually points to a Sem or ChildProc or StdIn
}

// handles int open(const char* fn, int flags) syscall
int openHandler(uint32_t* userEsp) {
	const char* fn = (const char*) userEsp[1];
	// int flags = (int) userEsp[2]; // flags in our implementation is ignored.

	// create Node* of the file dictated by fn
	Node* node = BobFS::findFileNodeFromAbsolutePath(fn, fileSystem);
	if (node == nullptr) return -1;

	// find an open descriptor in FDT of this process and set it to a new openFile struct
	FileDescriptorTable* fdt = active() -> fileDescriptorTable;
	ssize_t descriptor = fdt -> nextEmptyDescriptor();
	if (descriptor < 0) return -1; // FDT is full

	fdt -> set(descriptor, new OpenFile(node));
	return descriptor;
}

// handles ssize_t len(int fd)
ssize_t lenHandler(uint32_t* userEsp) {
	int fd = (int) userEsp[1];
	if (fd < 0) return -1;

	File* file = active() -> fileDescriptorTable -> get(fd);
	if (file == nullptr) return -1; // file does not exist (fd >= 3) or file is stdin, stdout, or stderr (fd = 0, 1, 2)

	return file -> size(); // polymorphism will return -1 if file actually points to a Sem or childProc or StdIn or StdOut
}

// handles ssize_t read(int fd, void* buf, size_t nbyte)
ssize_t readHandler(uint32_t* userEsp) {
	int fd = (int) userEsp[1];
	char* buf = (char*) userEsp[2];
	size_t nbytes = (size_t) userEsp[3];

	if (fd < 0) return -1; // invalid descriptor

	File* file = active() -> fileDescriptorTable -> get(fd);
	if (file == nullptr) return -1; // trying to read from a file that does not exist

	return file -> read(buf, nbytes); // polymorphism will return -1 if file actually points to a Sem or ChildProc or StdOut or StdErr or StdIn
}

// handles off_t seek(int fd, off_t offset)
off_t seekHandler(uint32_t* userEsp) {
	int fd = (int) userEsp[1];
	off_t offset = (off_t) userEsp[2];

	if (fd < 0) return -1;
	File* file = active() -> fileDescriptorTable -> get(fd);
	if (file == nullptr) return -1; // trying to seek in a file that does not exist

	return file -> seek(offset); // polymorphism will return -1 if file actually points to a Sem or ChildProc or StdIn or StdOut or StdErr
}

// handles int shutdown(void) 
int shutdownHandler(uint32_t* userEsp) {
	Debug::shutdown();
	return 0;
}

// handles int close(int id)
int closeHandler(uint32_t* userEsp) {
	int id = (int) userEsp[1];
	if (id < 0) return -1; // invalid file descriptor
	File* file = active() -> fileDescriptorTable -> get(id);
	if (file == nullptr) return -1; // trying to close a file that does not exist

	// delete file; 
	// TODO: think about how to write the destructor of File as well all its
	//       derived classes so as to prevent memory leakage.
	//       Now, simply set FDT[id] to nullptr.
	active() -> fileDescriptorTable -> set(id, nullptr);
	return 0;
}

// handles int sem(uint32_t init)
int semHandler(uint32_t* userEsp) {
	uint32_t init = (uint32_t) userEsp[1];

	// find an open descriptor in FDT of this process and set it to a new openFile struct
	FileDescriptorTable* fdt = active() -> fileDescriptorTable;
	ssize_t descriptor = fdt -> nextEmptyDescriptorReversed();
	if (descriptor < 0) return -1; // FDT is full

	fdt -> set(descriptor, new Sem(init));
	return descriptor;
}

// handles int up(int s)
int upHandler(uint32_t* userEsp) {
	int s = (int) userEsp[1];
	if (s < 0) return -1; // invalid descriptor

	File* sem = active() -> fileDescriptorTable -> get(s);
	if (sem == nullptr) return -1; // trying to call up on a Sem that does not exist

	return sem -> up(); // polymorphism will return -1 if file actually points to a OpenFile or ChildProc or StdIn or StdOut or StdErr
}

// handles int down(int s)
int downHandler(uint32_t* userEsp) {
	int s = (int) userEsp[1];
	if (s < 0) return -1; // invalid descriptor

	File* sem = active() -> fileDescriptorTable -> get(s);
	if (sem == nullptr) return -1; // trying to call up on a Sem that does not exist

	return sem -> down(); // polymorphism will return -1 if file actually points to a OpenFile or ChildProc or StdIn or StdOut or StdErr
}

// handles int wait(int id, uint32_t *status)
int waitHandler(uint32_t* userEsp) {
	int id = (int) userEsp[1];
	uint32_t* status = (uint32_t*) userEsp[2];

	if (id < 0) return -1; // invalid descriptor

	File* child = active() -> fileDescriptorTable -> get(id);
	if (child == nullptr) return -1; // trying to wait on child that does not exist

	return child -> waitToFinish(status);
}

// handles int fork()
int forkHandler(uint32_t* userEsp, uint32_t* frame) {
	// 0. find a place in current thread's FDT to hold the ChildProc resource
	FileDescriptorTable* parentFDT = active() -> fileDescriptorTable;
	ssize_t descriptor = parentFDT -> nextEmptyDescriptorReversed();
	if (descriptor < 0) return -1; // FDT is full
	parentFDT -> set(descriptor, new ChildProc());

	// 1. create a new ThreadImpl object -- the child process
	uint32_t e = (uint32_t) frame[0];
	Thread* childProc = createThread([e, userEsp] {
		switchToUser(e, (uint32_t) userEsp, 0);
	});

	// 2. copy the virtual address space in range [0x80000000, 0xEFFFFFFF] to the child process
	childProc -> addressSpace -> copyAddressSpaceFrom(active() -> addressSpace);

	// 3. set up the FDT of the child process
	for (uint32_t i = 0; i < 3; ++i) {
		// FDT[0], FDT[1], FDT[2] have already been set so now let's delete them first and then we can copy
		delete childProc -> fileDescriptorTable -> get(i);
	}
	for (uint32_t i = 0; i < FileDescriptorTable::MAX_RESOURCE_NUMBER; ++i) {
		File* parentFile = active() -> fileDescriptorTable -> get(i);
		if (parentFile != nullptr) {
			childProc -> fileDescriptorTable -> set(i, parentFile -> clone()); // polymorphism will return a pointer to either a new OpenFile structur (if it's a OpenFile) or the same Sem object (if it's a Sem) or nullptr (if it's a ChildProc).
		}
	}

	// 4. set up the Future<int> "hasFinished" in childProc to point to the Future inside ChildProc object in parentFDT[descriptor]
	childProc -> hasFinished = &(((ChildProc*) (parentFDT -> get(descriptor))) -> hasFinished);

	// 5. schedule the child process
	schedule(childProc);

	// 6. return child process descriptor
	return descriptor;

}

// handles int execl(const char* path, const char* arg0, ...)
int execlHandler(uint32_t* userEsp) {
	// TODO: finish execl!
	// find the Node* from path (this Node* will be stored in kernel heap memory)
	// argv, agrc in kernel heap
	// wipe address space
	// load the program using ELF::load(Node*)
	// setting up the user stack (esp < 0xeffff000)
	// switchToUser(pc=elf loaded in, esp, eax=0)
	char* path = (char*) userEsp[1];
	Node* userProgramToRun = BobFS::findFileNodeFromAbsolutePath(path, fileSystem);

	uint32_t argc = 1;
	while (userEsp[++argc] != 0);
	argc -= 2;
	Debug::printf("argc = %d\n", argc);

	char* argv[argc];
	for(uint32_t i = 0; i < argc; ++i) {
		argv[i] = (char*) userEsp[i+2];
		Debug::printf("%s\n", argv[i]);
	}

	// now let's store argc and argv to kernel heap
	// argc (1 word), argv (1 word), 
	// argv[0] (1 word), ..., argv[argc-1] (1 word), NULL (1 word), 
	// actual_string_for_argv[0] (ceil((len+1)/4) words),
	// ...,
	// actual_string_for_argv[argc-1] (ceil((len+1)/4) words).
	// hopefully 50 words is enough.
	char* temp = (char*) malloc(3000); 

	char* firstHalf =  temp;
	if (((uint32_t) temp % 4) != 0) Debug::panic("intial temp is not 4B aligned.");
	char* secondHalf = temp + (3 + argc) * 4;
	char* initialSecondHalf = secondHalf;

	// store argc
	*((uint32_t*) firstHalf) = argc;
	firstHalf += 4;

	// store argv
	*((uint32_t*) firstHalf) = ((uint32_t) firstHalf) + 4;
	firstHalf += 4;

	// store argv[0], ..., argv[argc-1]
	for (uint32_t i = 0; i < argc; ++i, firstHalf+=4) {
		*((uint32_t*) firstHalf) = (uint32_t) secondHalf;
		// store the actual string argv[i] points to in secondHalf
		uint32_t j = 0;
		for(; j < strlen(argv[i]); ++j, ++secondHalf) {
			*secondHalf = argv[i][j];
		}
		*secondHalf = '\0';
		secondHalf += 1;
		while ((secondHalf - temp) % 4 != 0) {
			secondHalf += 1;
		}
	}

	// store NULL
	*((uint32_t*) firstHalf) = 0;
	firstHalf += 4;

	if (initialSecondHalf != firstHalf || ((uint32_t) secondHalf) % 4 != 0)
	Debug::panic("the arithmetic is wrong here because firstHalf = 0x%x, initialSecondHalf = 0x%x, secondHalf = 0x%x", firstHalf, initialSecondHalf, secondHalf);
	
	// now we're going to wipe out the address space
	AddressSpace* emptyAddressSpace = new AddressSpace(false);
	active() -> addressSpace -> copyAddressSpaceFrom(emptyAddressSpace);
	delete emptyAddressSpace;

	// load the program to run with ELF::load
	uint32_t e = ELF::load(userProgramToRun);

	// setting up the user stack (esp < 0xeffff000) by copying [temp, secondHalf)
	char* esp = (char*) (0xeffff000 - 3000);
	char* espFirstHalf = esp;
	char* espSecondHalf = esp + (firstHalf - temp);
	firstHalf = temp;
	secondHalf = initialSecondHalf;
	// copy argc (temp[0])
	*((uint32_t*) espFirstHalf) = *((uint32_t*) firstHalf);
	espFirstHalf += 4;
	firstHalf += 4;
	// copy argv 
	*((uint32_t*) espFirstHalf) = ((uint32_t) espFirstHalf) + 4;
	espFirstHalf += 4;
	firstHalf += 4;
	// copy argv[0], argv[1], ..., argv[argc-1]
	for (uint32_t i = 0; i < argc; ++i, espFirstHalf+=4, firstHalf+=4) {
		*((uint32_t*) espFirstHalf) = (uint32_t) espSecondHalf;
		// set up espSecondHalf accordingly
		uint32_t j = 0;
		while (secondHalf[j] != '\0') {
			espSecondHalf[j] = secondHalf[j];
			j += 1;
		}
		espSecondHalf[j] = '\0';
		secondHalf += (j+1);
		espSecondHalf += (j+1);
		if (espSecondHalf - esp != secondHalf - temp) Debug::panic("espSecondHalf is not in parallel with secondHalf.");
		while ((espSecondHalf - esp) % 4 != 0) {
			espSecondHalf += 1;
			secondHalf += 1;
		}
	}
	if ((espSecondHalf - esp != secondHalf - temp) || (espFirstHalf - esp) != (firstHalf - temp) ) Debug::panic("something wrong in arithmetic!!!");


	// switchToUser(pc=elf loaded in, esp, eax=0)
	switchToUser(e, (uint32_t) esp, 0);
	return 0;
}

extern "C" int sysHandler(uint32_t eax, uint32_t *frame) {
	// get the user stack pointer, which stores all the arguments passed to the system call
	uint32_t* userEsp = (uint32_t*) frame[3];

	switch(eax) {
		case 0:
			return exitHandler(userEsp);
		case 1:
			return writeHandler(userEsp);
		case 2:
			return forkHandler(userEsp, frame);
		case 3:
			return semHandler(userEsp);
		case 4:
			return upHandler(userEsp);
		case 5:
			return downHandler(userEsp);
		case 6:
			return closeHandler(userEsp);
		case 7:
			return shutdownHandler(userEsp);
		case 8:
			return waitHandler(userEsp);
		case 9:
			return execlHandler(userEsp);
		case 10:
			return openHandler(userEsp);
		case 11:
			return lenHandler(userEsp);
		case 12:
			return readHandler(userEsp);
		case 13:
			return seekHandler(userEsp);
		default:
			Debug::printf("Unknow syscall type = %d\n", eax);;
			Debug::panic("");
			return -1;
	}
}

void SYS::init(void) {
    IDT::trap(48,(uint32_t)sysHandler_,3);
}
