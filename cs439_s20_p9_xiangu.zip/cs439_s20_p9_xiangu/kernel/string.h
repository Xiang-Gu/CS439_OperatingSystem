#ifndef _STRING_H_
#define _STRING_H_

#include "stdint.h"

uint32_t strlen(const char* str) {
	uint32_t result = 0;
	while (str[result] != '\0') {
		result += 1;
	}
	return result;
}


#endif



