#include "file.h"

// extern BobFS* fileSystem;

// OpenNodes openNodes(fileSystem);
