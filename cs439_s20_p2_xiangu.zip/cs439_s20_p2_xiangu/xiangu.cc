#include "stdint.h"
#include "heap.h"
#include "random.h"
#include "smp.h"
#include "debug.h"

/* 
Try to stress first-fit strategy and favor a best-fit strategy as discussed in my report (question 3).
*/
void kernelMain(void) {
    uint32_t me = SMP::me();
    if (me == 2) {
        // repeated by malloc two small chunks of memory and free the previous one
        // a first-fit strategy (probably) will keep using the same large free node
        // and hence causing a fragmented memory after many such operations.
        // best-fit won't have this problem and all the allocated will reside on one
        // side of memory and gradually grows towards the other side.
        void* ptr = nullptr;
        for (int i = 0; i < 1000000; ++i) {
            void* ptr= malloc(1000);
            malloc(1000);
            free(ptr);
        }

        // now try to malloc a large chunck of memory and hopefully first-fit will cause the 
        // heap to be too fragmented to host this request while best-fit can.
        ptr = malloc(1000000);

        if (ptr == nullptr) {
            Debug::printf("*** failed to accomondate this large request.\n");
        } else {
            Debug::printf("*** succeed to accomondate this large request.\n");
        }

        Debug::shutdown();
    } else {
       while (true) asm volatile("hlt");
    }
}

