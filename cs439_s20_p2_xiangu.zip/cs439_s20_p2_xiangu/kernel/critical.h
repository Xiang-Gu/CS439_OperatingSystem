#ifndef _CRITICAL_H_
#define _CRITICAL_H_

void critical_begin();
void critical_end();

#endif
