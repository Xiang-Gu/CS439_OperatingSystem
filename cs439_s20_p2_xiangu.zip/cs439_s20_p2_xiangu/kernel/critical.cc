#include "critical.h"

void critical_begin() {
}

void critical_end() {
}
