#include "heap.h"
#include "debug.h"
#include "stdint.h"
#include "atomic.h"

/********************/
/* helper functions */
/********************/

// adds offset (in unit of bytes) to pointer p
// and return resulting pointer as a T*.
template<typename T>
inline T* ptr_add(void* p, int offset) {
	return (T*) (((char*) p) + offset);
}

// return the absolute value of numeric value x
template<typename T>
inline T abs(T x) {
	if (x < 0) return -x;
	return x;
}

// return the number of words for bytes, satisfying
// alignment requirement.
// (e.g. bytes=30, bytesPerWord=4, return 8 words 
// because 8 words = 32 bytes is the smallest number of bytes 
// that is multiple of 4 and larger than 30)
inline int byte2WordRoundUp(int bytes, int bytesPerWord) {
	if (bytes % bytesPerWord == 0) {
		return bytes / bytesPerWord;
	}
	return (bytes / bytesPerWord) + 1;
}


/********************/
/* helper structurs */
/********************/

struct Footer {
	// should be identical to size in Header 
	int size;
};

struct Header {
	// size (in unit of words) of this whole node. 
	// positive means taken; negative means free.
	int size; 

	// pointer to the Header of previous free node.
	// if curent node is taken, then this field
	// is wasted and the value should not be used.
	Header* prevFree;

	// pointer to the Header of next free node.
	// If current node is taken, then this field
	// is wasted and the value should not be used.
	Header* nextFree;

	// is this node a free node?
	inline bool isFree() {
		return size < 0;
	}

	// return a pointer to the header of next node by boldly
	// adding to this pointer. Hence the user is responsible 
	// for checking whether current node is the last node.
	inline Header* hopRight() {
		return ptr_add<Header>(this, abs<int>(size) * 4);
	}

	// return a pointer to the Header of previous node by
	// boldy subtracting from this pointer.
	inline Header* hopLeft() {
		int unsignedSizeOfLeftNodeInWords = abs(ptr_add<Footer>(this, -4) -> size);
		return ptr_add<Header>(this, -unsignedSizeOfLeftNodeInWords * 4);
	}

	// get the corresponding Footer of this node
	inline Footer* getFooter() {
		return ptr_add<Footer>(hopRight(), -4);
	}
};



/******************************/
/* Global Variable Definition */
/******************************/

// pointer to the begining of the heap
void* startOfHeap = nullptr; 
// size of the heap (in bytes)
int sizeOfHeap = 0; 
// pointer to the Header of the first free node
Header* freeNodesStart = nullptr;
// protect malloc() and free() for each core
SpinLock spinlock;


// remove free node from the free node list
// precondition: ptr -> isFree() == true
void removeNodeFromFNL(Header* ptr) {
	if (ptr -> prevFree == nullptr && ptr -> nextFree == nullptr) {
		// Debug::printf("remove first (and only) node in FNL!\n");
		freeNodesStart = nullptr;
	} else if (ptr -> prevFree == nullptr && ptr -> nextFree != nullptr) {
		// Debug::printf("remove first node in FNL!\n");
		freeNodesStart = ptr -> nextFree;
		ptr -> nextFree -> prevFree = nullptr;
	} else if (ptr -> prevFree != nullptr && ptr -> nextFree == nullptr) {
		// Debug::printf("remove last node in FNL!\n");
		ptr -> prevFree -> nextFree = nullptr;
	} else {
		// Debug::printf("remove a middle node in FNL!\n");
		ptr -> prevFree -> nextFree = ptr -> nextFree;
		ptr -> nextFree -> prevFree = ptr -> prevFree;
	}
}


// precondition: current node is free;
// 				 right node exists; 
//               right node is also free.
void mergeRight(Header* ptr) {
	// 0. remember the Header of the node on the right
	Header* headerOfRightNode = ptr -> hopRight();
	// 1. change the size of current node
	int signedSizeAfterMerge = (ptr -> size) + (headerOfRightNode -> size);
	ptr -> size = signedSizeAfterMerge;
	ptr -> getFooter() -> size = signedSizeAfterMerge;
	// 2. remove the right free node from the free node list
	removeNodeFromFNL(headerOfRightNode);
}


/****************************/
/* debugging tool functions */
/****************************/

// check invariance of heap to see whether the heap is valid.
// useful in debugging stage.
// check
// 1. we don't have two adjacent free node;
// 2. Header's size == Footer's zie for each node;
// 3. all nodes (Header, data, Footer) add up to bytes; 
// 4. all free nodes are in the free node list (FNL);
// 5. free node list contain only the free nodes (so no more no less).
bool isValid(void* start, int bytes) {
	Header* ptr = (Header*) start;
	bool isPreviousFree = false;
	int numFreeNodes = 0;

	while ((((char*) ptr) - ((char*) start)) < bytes) {
		// signal error if we have adjacent free nodes
		if (isPreviousFree && ptr -> isFree()) {
			Debug::printf("have adjacent free nodes!\n");
			return false;
		}

		// if it's a free node, check whether it's in the free node list
		if (ptr -> isFree()) {
			numFreeNodes += 1;
			bool findThisFreeNodeFromFNL = false;
			// try to find this free node from the free node list
			Header* curr = freeNodesStart;
			while (curr != nullptr) {
				if (curr == ptr) {
					// good!!! find current node in the free node list
					findThisFreeNodeFromFNL = true;
					break;
				}
				curr = curr -> nextFree;
			}
			// signal error if we didn't find current free node from the free node list.
			if (!findThisFreeNodeFromFNL) {
				Debug::printf("Did not find current free node from FNL\n");
				return false;
			}
		}

		// signal error if Header.size != Footer.size
		if (ptr -> size != ptr -> getFooter() -> size) {
			Debug::printf("Header size does not match Footer size! Header size = %d, Footer size = %d\n", ptr->size, ptr->getFooter()->size);
			return false;
		}

		// update free flag
		isPreviousFree = ptr -> isFree();

		// move to the next node
		ptr = ptr -> hopRight();
	}

	// signal error if all the nodes don't add up to bytes.
	if ((((char*) ptr) - ((char*) start)) != bytes) {
		Debug::printf("all nodes do not add up to original heap size!\n");
		return false;
	}

	// signal error if the number of nodes in free node list is not 
	// equal to the number of free nodes found after traversing all nodes.
	int numFreeNodesFromFNL = 0;
	ptr = (Header*) freeNodesStart;
	while (ptr != nullptr) {
		numFreeNodesFromFNL += 1;
		ptr = ptr -> nextFree;
	}
	if (numFreeNodes != numFreeNodesFromFNL) {
		Debug::printf("size of FNL does not match # of free node found via traversal! size_FNL = %d, free nodes via traversal = %d\n", numFreeNodesFromFNL, numFreeNodes);
		return false;
	}

	// congrats, our heap passed all sanity checks. (probably) it's valid!
	return true;
}

// print out each node and their size from left to right
void traverseAllNodes() {
	Header* ptr = (Header*) startOfHeap;
	int nodeIdx = 0;
	while ((((char*) ptr) - ((char*) startOfHeap)) < sizeOfHeap) {
		Debug::printf("%d-th node, size = %d\t", nodeIdx, ptr -> size);
		ptr = ptr_add<Header>(ptr, abs(ptr->size) * 4);
		nodeIdx += 1;
	}
	Debug::printf("\n\n");
}

void traverseFNL() {
	Debug::printf("FNL contains (not in any particular order): ");
	Header* curr = freeNodesStart;
	while (curr != nullptr) {
		Debug::printf("block %d ", curr -> size);
		curr = curr -> nextFree;
	}
}



void heapInit(void* start, size_t bytes) {
    startOfHeap = start;
    sizeOfHeap = bytes;
    freeNodesStart = (Header*) start;
    spinlock = SpinLock();

    // Put in Header, pointer (to the next free node. nullptr in this case), and a Footer
    // to initialize the raw heap memory as one (large) free node.
    freeNodesStart -> size = -byte2WordRoundUp(bytes, 4);
    freeNodesStart -> prevFree = nullptr;
    freeNodesStart -> nextFree = nullptr;
    freeNodesStart -> getFooter() -> size = freeNodesStart -> size;

    // if (!isValid(startOfHeap, sizeOfHeap)) {
    // 	Debug::printf("heapInit failed!\n");
    // } else {
    // 	Debug::printf("heapInit succeeded!\n");
    // }
}

// first-fit policy
void* malloc(size_t bytes) {

	// don't even bother to check anything if requested memory is > heap size.
	if ((int) bytes > sizeOfHeap - 8 || (int) bytes < 0) {
		// Debug::printf("I don' have that much memory left. sorry!\n");
		return nullptr;
	}
	// return one past the last byte in heap if malloc(0)
	if (bytes == 0) {
		return (void*) (((char*) startOfHeap) + sizeOfHeap);
	}


	spinlock.lock();
	int requestedMemInWords = byte2WordRoundUp(bytes, 4);
	if (requestedMemInWords < 2) requestedMemInWords = 2;

	Header* freeNodePtr = freeNodesStart;

	while (freeNodePtr != nullptr) {
		// good, we find a free node to host the request
		if (requestedMemInWords <= abs(freeNodePtr -> size) - 2) {
			// however, if requested memory is large enough so that the rest will be too small
			// to be a free node (i.e. only 3 words or less is left), then we just allocate
			// the whole node to the user
			if (requestedMemInWords >= abs(freeNodePtr -> size) - 6) {
				// 1. negate the size sign in both Header and Footer
				freeNodePtr -> size *= -1;
				freeNodePtr -> getFooter() -> size *= -1;
				// 2. remove this node from free node list
				removeNodeFromFNL(freeNodePtr);
				// 3. return a pointer to the start of block in this node

				// if (!isValid(startOfHeap, sizeOfHeap)) {
			 //    	Debug::printf("something wrong after malloc size = %d node! (no split case)\n", byte2WordRoundUp(bytes,4) + 2);
				// 	traverseAllNodes();
				// 	traverseFNL();
			 //    	Debug::shutdown();
			 //    } else {
			 //    	Debug::printf("heap good after malloc size = %d node!\n", byte2WordRoundUp(bytes,4) + 2);
			 //    	traverseAllNodes();
			 //    	traverseFNL();
			 //    }

				spinlock.unlock();
				return ptr_add<void>(freeNodePtr, 4);
			} else {
				// otherwise, split this free node
				// 1. change the size in the remaining free node (on the left) and
				// the newly-allocated taken node (on the right)
				freeNodePtr -> size = -(abs(freeNodePtr -> size) - requestedMemInWords - 2);
				freeNodePtr -> getFooter() -> size = freeNodePtr -> size;
				freeNodePtr -> hopRight() -> size = requestedMemInWords + 2;
				freeNodePtr -> hopRight() -> getFooter() -> size = requestedMemInWords + 2;
				// 2. no need to change anything in the free node list because we allocated
				// block from the right
				// 3. return a pointer to the start of block in the newly-split node

				// if (!isValid(startOfHeap, sizeOfHeap)) {
			 //    	Debug::printf("something wrong after malloc size = %d node! (split case)\n", byte2WordRoundUp(bytes,4) + 2);
				// 	traverseAllNodes();
				// 	traverseFNL();
			 //    	Debug::shutdown();
			 //    } else {
			 //    	Debug::printf("heap good after malloc size = %d node!\n", byte2WordRoundUp(bytes,4) + 2);
			 //    	traverseAllNodes();
			 //    	traverseFNL();
			 //    }

				spinlock.unlock();
				return ptr_add<void>(freeNodePtr -> hopRight(), 4);
			}
			Debug::printf("This should not happen! Something is wrong in malloc!\n");
		}
		// this one isn't large enough, go try the next free node
		freeNodePtr = freeNodePtr -> nextFree;		
	}

	// Debug::printf("Unable to find a large enough free node to host your request. Sorry!\n");
	spinlock.unlock();
	// cannot find any eligible free node to allocate memory
	return nullptr;
}

void free(void* p) {
	// do nothing if we try to free nullptr or free invalid address (returned by malloc(0))
	if (p == nullptr) return;
	if (p == ((char*) startOfHeap) + sizeOfHeap) return;

	spinlock.lock();
	Header* headerOfNodeToFree = ptr_add<Header>(p, -4);

    // 1. negate sign of size of both Header and Footer
    headerOfNodeToFree -> size *= -1;
    headerOfNodeToFree -> getFooter() -> size *= -1;
    // 2. add this new free node to the begining our free node list
    if (freeNodesStart == nullptr) {
    	// Debug::printf("only node in FNL!\n");
		freeNodesStart = headerOfNodeToFree;
		headerOfNodeToFree -> prevFree = nullptr;
		headerOfNodeToFree -> nextFree = nullptr;
    } else {
    	// Debug::printf("not the only node in FNL!\n");
	    headerOfNodeToFree -> prevFree = nullptr;
	    headerOfNodeToFree -> nextFree = freeNodesStart;
	    freeNodesStart = headerOfNodeToFree;
	    headerOfNodeToFree -> nextFree -> prevFree = headerOfNodeToFree;
    }


    // 3. merge with right node if there is a right node AND it is also free
    if ((char*) (headerOfNodeToFree -> hopRight()) < (((char*) startOfHeap) + sizeOfHeap) && headerOfNodeToFree -> hopRight() -> isFree()) {
		// Debug::printf("merge right\n");
		mergeRight(headerOfNodeToFree);
    }  
    // 4. merge with left node if there is a left node AND it is also free
    if (((char*) headerOfNodeToFree) > ((char*) startOfHeap) && headerOfNodeToFree -> hopLeft() -> isFree()) {
    	// Debug::printf("merge left!\n");
		mergeRight(headerOfNodeToFree -> hopLeft());
    }

	// if (!isValid(startOfHeap, sizeOfHeap)) {
 //    	Debug::printf("something wrong after free(%d)!\n", headerOfNodeToFree->size);
	// 	traverseAllNodes();
	// 	traverseFNL();
 //    	Debug::shutdown();
 //    } else {
 //    	Debug::printf("heap good after free(%d)!\n", headerOfNodeToFree->size);
 //    	traverseAllNodes();
 //    	traverseFNL();
 //    }

	spinlock.unlock();
	
}






/*****************/
/* C++ operators */
/*****************/

void* operator new(size_t size) {
    void* p =  malloc(size);
    if (p == 0) Debug::panic("out of memory");
    return p;
}

void operator delete(void* p) noexcept {
    return free(p);
}

void operator delete(void* p, size_t sz) {
    return free(p);
}

void* operator new[](size_t size) {
    void* p =  malloc(size);
    if (p == 0) Debug::panic("out of memory");
    return p;
}

void operator delete[](void* p) noexcept {
    return free(p);
}

void operator delete[](void* p, size_t sz) {
    return free(p);
}
