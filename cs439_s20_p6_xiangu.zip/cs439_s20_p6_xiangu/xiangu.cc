#include "stdint.h"
#include "debug.h"
#include "ide.h"
#include "bobfs.h"

/*
This is a simple test where I just tried to make a BobFS out of an empty disk. Then create a few directories
as well as files. Then I called a few interfaces functions, such as findNode, writeAll, readAll, getType, getSize, etc.,
to see whether it's working correctly.
*/
void kernelMain(void) {

    Ide* disk = new Ide(3);
    BobFS* fs = BobFS::mkfs(disk);
    Node* root = BobFS::root(fs);

    root -> newDirectory("user1");
    root -> newDirectory("user2");
    root -> newDirectory("user3");
    root -> newFile("allUserInfo");

    Node* allUserInfo = root -> findNode("allUserInfo");
    if (allUserInfo == nullptr)
        Debug::printf("*** this should not appear: didn't create file and find file correctly.\n");

    allUserInfo -> writeAll(0, "user1 : xiang, user2 : gheith, user3 : cs439", 44);
    char buffer[45];
    buffer[44] = '\0';
    allUserInfo -> readAll(0, buffer, 44);
    if (!streq(buffer, "user1 : xiang, user2 : gheith, user3 : cs439"))
        Debug::printf("*** this should not happen: didn't read-and-write correctly.\n");

    Node* user1 = root -> findNode("user1");
    if (user1 == nullptr)
        Debug::printf("*** this should not appear: didn't create directory and find it correctly.\n");
    else if (user1 -> getType() != Node::DIR_TYPE || user1 -> getSize() != 0 || user1 -> getLinks() != 1)
        Debug::printf("*** this should not appear: newly created directory didn't have correct type (DIR_TYPE) or size (0) or links (1).\n");


    Debug::printf("*** you passed the test!\n");    
}
