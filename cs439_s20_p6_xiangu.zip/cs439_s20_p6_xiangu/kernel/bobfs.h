#ifndef _BOBFS_H_
#define _BOBFS_H_

#include "ide.h"
#include "libk.h"
#include "heap.h"
#include "debug.h"

class BobFS;

extern uint32_t findRootinumberFromDevice(Ide* device);
extern uint32_t nameLength(const char* name);
extern bool streq(const char*, const char*);

/* In-memory representation of an i-node */
class Node {
private:
    BobFS* fs;
    uint32_t inumber;

    uint16_t type;
    uint16_t nlinks;
    uint32_t size;
    uint32_t directBlockNumber;
    uint32_t indirectBlockNumber;

    // helper method 0: write back current node information to device
    void syncBackToDevice();

	// helper method 1: add an entry in current directory i-node's data
	void addDirectoryEntryAndSync(uint32_t inumber, const char* name);

    // helper method 2: find the byte address of offset in file
    // recall that offset is address within the file. we want to find the byte address on device that stores the data at offset.
    uint32_t offsetInFile2ByteAddrOnDevice(uint32_t offset);

    // helper method 3: allocate new block(s) for this node because we are going to write some data to this node
    void allocateBlocksFromBytesNeeded(uint32_t bytesNeededAfterSize);

public:
    static constexpr uint32_t SIZE = 16;
    static constexpr uint16_t DIR_TYPE = 1;
    static constexpr uint16_t FILE_TYPE = 2;

    /* Create a Node object representing the given i-node
       in the given file system */
    Node(BobFS* fs, uint32_t inumber);

    /* node type */
    uint16_t getType(void);

    /* number of links to this node */
    uint16_t getLinks(void);

    /* size of the data represented by this node */
    uint32_t getSize(void);

    /* read up to "n" bytes and store them in the given "buffer"
       starting at the given "offset" in the file

       returns: number of bytes actually read
                x = 0      ==> end of file
                x < 0      ==> error
                0 < x <= n ==> number of bytes actually read
     */ 
    int32_t read(uint32_t offset, void* buffer, uint32_t n);

    /* like read but promises to read as many bytes as it can */
    int32_t readAll(uint32_t offset, void* buffer, uint32_t n);

    /* writes up to "n" bytes from the given "buffer"
       starting at the given "offset" in the file

       returns: number of bytes actually written
                x = 0      ==> end of file
                x < 0      ==> error
                0 > x <= n ==> number of bytes actually written
     */ 
    int32_t write(uint32_t offset, const void* buffer, uint32_t n);

    /* like write but promises to write as many bytes as it can */
    int32_t writeAll(uint32_t offset, const void* buffer, uint32_t n);

    /* If the current node is a directory, create an entry
       with the given information and return a pointer to the
       Node representing the new entry

       returns null if the current Node is not a directory

     */
    Node* newNode(const char* name, uint32_t type);

    /* calls newNode to create a file */
    Node* newFile(const char* name);

    /* calls newNode to create a directory */
    Node* newDirectory(const char* name);

    /* if the current node is a directory, returns a pointer to
       the entry with the given name */
    Node* findNode(const char* name);

    bool isFile(void);

    bool isDirectory(void);

    /* Creates a new link to the given node in this directory */
    /* does nothing if the current node is not a directory */
    void linkNode(const char* name, Node* file);

    void dump(const char* name);

    static Node* get(BobFS* fs, uint32_t index) {
        Node* n = new Node(fs,index);
        return n;
    }
};





/* In-memory representation of a BobFS file system */
class BobFS {
public:
    // declare class Node as a friend class so that Node's methods can call BobFS's private helper method
    friend class Node;
    static constexpr uint32_t BLOCK_SIZE = 1024;
    static constexpr uint32_t MAX_NODE_SIZE = (BLOCK_SIZE / 4 + 1) * BLOCK_SIZE; // max data size that a node can contain

private:    
    Ide* device;
    uint32_t rootinumber;
    char blocksBitMap[BLOCK_SIZE];
    char inodesBitMap[BLOCK_SIZE];

    // helper method 0: write blocksBitMap to device (should be invoked if blockBitMap is modified)
    void writeBackBlocksBitMap();

    // helper method 1: wrtie inodesBitMap to device (should be invoked if inodesBitMap is modified)
    void writeBackinodesBitMap();

    // helper method 2: update blocksBitMap because block blockNumber has been allocated (if taken) or freed (if not taken)
    //                  and write the changed blocksBitMap back to device.
    void updateblocksBitMap(uint32_t blockNumber, bool taken);

    // helper method 3: update inodesBitMap because i-node inumber has been taken (if taken) or freed (if not taken)
    //                  and write the changed inodesBitMap back to device
    void updateinodesBitMap(uint32_t inumber, bool taken);

    // helper method 4: find the next empty block number. Return -1 if all blocks are taken
    int nextEmptyBlockNumber();

    // helper method 5: find the next empty i-node number. Return -1 if there is not empty i-node left.
    int nextEmptyinumber();

    // helper method 6: update an i-node
    void updateinode(uint32_t inumber, uint16_t type, uint16_t nlinks, uint32_t size, uint32_t direct, uint32_t indirect);

    // helper method 7: allocate one empty free block and return the block number
    uint32_t allocateAnEmptyBlock();

    // helper method 8: allocate one empty i-node and return the i-node number
    uint32_t allocateAnEmptyinode();

public:
    BobFS(Ide* device);

    virtual ~BobFS();

    /* make a new BobFS file system on the given device */
    static BobFS* mkfs(Ide* device);

    /* mount an existing BobFS file system from the given device */
    static BobFS* mount(Ide* device);

    /* Return a pointer to the root node of the given file system */
    static Node* root(BobFS* fs);

};

#endif
