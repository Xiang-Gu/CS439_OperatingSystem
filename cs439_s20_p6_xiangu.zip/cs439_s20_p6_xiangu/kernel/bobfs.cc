#include "bobfs.h"
#include "libk.h"
#include "heap.h"
#include "debug.h"

uint8_t zero_1024[BobFS::BLOCK_SIZE];

/*
TODO:
	1. Node::read and Node::write, what are the "error" cases
	2. Organize my code -- .h and .cc distinguishing.

*/

//////////////////////
// Helper Functions //
//////////////////////

// compare two C-strings
bool streq(const char* a, const char* b) {
    int i = 0;

    while (true) {
        char x = a[i];
        char y = b[i];
        if (x != y) return false;
        if (x == 0) return true;
        i++;
    }
}

// find length of a C-string
uint32_t nameLength(const char* name) {
    uint32_t result = 0;
    while (name[result] != '\0')
        result++;
    return result;
}

// find root i-number from a correctly configured device
uint32_t findRootinumberFromDevice(Ide* device) {
    // precondition: device must be a correctly configured per BobFS spec.
    char magicNumber[9];
    device -> readAll(0, magicNumber, 8);
    magicNumber[8] = '\0';
    if (!streq("BOBFS439", magicNumber))
        Debug::panic("device is not correctly configured!!!");

    uint32_t rootinumber = -1;
    device -> readAll(8, &rootinumber, 4);
    if (rootinumber < 0 || rootinumber >= 8 * 1024)
        Debug::panic("failed to read root i-number!!!");

    return rootinumber;
}



//////////
// Node //
//////////

Node::Node(BobFS* fs, uint32_t inumber)  {
    this -> fs = fs;
    this -> inumber = inumber;

    Ide* device = fs -> device;
    char buffer[4];
    int inodeStart = 3 * 1024 + 16 * inumber;
    // read in type
    device -> readAll(inodeStart, buffer, 2);
    this -> type = *((uint16_t*) buffer);
    // read in nlinks
    device -> readAll(inodeStart + 2, buffer, 2);
    this -> nlinks = *((uint16_t*) buffer);
    // read in size
    device -> readAll(inodeStart + 4, buffer, 4);
    this -> size = *((uint32_t*) buffer);
    // read in direct block number
    device -> readAll(inodeStart + 8, buffer, 4);
    this -> directBlockNumber = *((uint32_t*) buffer);
    // read in indirect block number
    device -> readAll(inodeStart + 12, buffer, 4);
    this -> indirectBlockNumber = *((uint32_t*) buffer);
}

uint16_t Node::getType(void) {
    return type;
}

uint16_t Node::getLinks(void) {
    return nlinks;
}

uint32_t Node::getSize(void) {
    return size;
}

bool Node::isDirectory(void) {
    return getType() == DIR_TYPE;
}

bool Node::isFile(void) {
    return getType() == FILE_TYPE;
}

Node* Node::findNode(const char* name) {
    // precondition: current must be a directory node
    if (type != DIR_TYPE) 
        Debug::panic("Can only call findNode on a directory type node!!!");

    // buffer stores directory entries
    char buffer[size];
    readAll(0, buffer, size);

    // sequentially look at each entry in the directory and see whether we can find the matching one.
    uint32_t idx = 0;
    while (idx < size) {
        uint32_t inumberOfNextEntry = *((uint32_t*) (buffer + idx));
        idx += 4;
        uint32_t nameLenOfNextEntry = *((uint32_t*) (buffer + idx));
        idx += 4;
        // read the name and construct a c string (zero terminated)
        char nameOfNextEntry[nameLenOfNextEntry + 1];
        for (uint32_t i = 0; i < nameLenOfNextEntry; ++i)
            nameOfNextEntry[i] = buffer[idx + i];
        nameOfNextEntry[nameLenOfNextEntry] = '\0';

        if (streq(nameOfNextEntry, name)) {
            // find the node!
            return new Node(fs, inumberOfNextEntry);
        }

        idx += nameLenOfNextEntry;
    }
    // sadly, cannot find it
    return nullptr;
}


int32_t Node::write(uint32_t offset, const void* buffer, uint32_t n) {
	// precondition: 0 <= offset <= size
	if (offset < 0 || offset > size) {
		Debug::printf("*** ERROR: offset must be in [0, %d] in Node::write!!!\n", size);
		return -1;
	}

	// cannot write to this file anymore; it's full!
	if (size == 257 * 1024) {
		Debug::printf("Warning: end of file!!!\n");
		return 0;
	}

	uint32_t start = offsetInFile2ByteAddrOnDevice(offset);
	// Debug::printf("offset = %d, start in device = %d\n", offset, start);
	// write at most to the end of the block in device that contains data at offset in file.
	if (offset / 1024 != (offset + n) / 1024)
		n = 1024 - offset % 1024;
	// update size if it gets bigger after writting
	if (offset + n > size){
		size = offset + n;
		syncBackToDevice(); // lied here but quickly make it up in the return statement below
	}

	return fs -> device -> writeAll(start, buffer, n);


}

int32_t Node::writeAll(uint32_t offset, const void* buffer_, uint32_t n) {
	// one special corner case: when offset > size, we need to pad 0's till offset and 
	// then write whatever in buffer_ from offset for n bytes
	if (offset > size) {
		uint8_t* zeros = new uint8_t[offset - size];
		for (uint32_t i = 0; i < offset - size; ++i)
			zeros[i] = 0;
		// Debug::printf("special case in writeAll(%d, buffer, %d) when size = %d\n", offset, n, size);
		writeAll(size, zeros, offset - size);
		delete [] zeros;
	}

	// assert(offset <= size)

	// allocate blocks first if needed
	if (offset + n > size && (size - 1) / BobFS::BLOCK_SIZE != (offset + n - 1) / BobFS::BLOCK_SIZE) {
		allocateBlocksFromBytesNeeded(offset + n - size);
	}


    int32_t total = 0;
    const char* buffer = (const char*) buffer_;

    while (n > 0) {
        int32_t cnt = write(offset,buffer,n);
        if (cnt <= 0) return total;

        total += cnt;
        n -= cnt;
        offset += cnt;
        buffer += cnt;
    }
    return total;
}

int32_t Node::read(uint32_t offset, void* buffer, uint32_t n) {
    // error
    if (offset > size)
        return -1;
    // end of file
    if (offset == size)
        return 0;
    // "normalize" n so that offset + n <= size
    if (offset + n > size) 
        n = size - offset;

    // the following code handle the read operation with the 
    // assumption offset < size and offset + n <= size
    uint32_t start = offsetInFile2ByteAddrOnDevice(offset);
	// set n such that offset + n will read at most the current block on device that contains data at offset in file
    if (offset / 1024 != (offset + n) / 1024)
    	n = 1024 - offset % 1024;

    return fs -> device -> readAll(start, buffer, n);
}


int32_t Node::readAll(uint32_t offset, void* buffer_, uint32_t n) {
	// Debug::printf("readAll(%d, buffer, %d)\n", offset, n);
	int32_t total = 0;
    char* buffer = (char*) buffer_;

    while (n > 0) {
        int32_t cnt = read(offset,buffer,n);
        if (cnt <= 0) return total;

        total += cnt;
        n -= cnt;
        offset += cnt;
        buffer += cnt;
    }
    return total;
}

void Node::linkNode(const char* name, Node* node) {
    // precondition: file must be a file i-node
    if (node -> type != FILE_TYPE) 
        Debug::panic("Cannot create hard-links to directories. Can only create hard-links to files.");

    // does nothing if current node is not a directory
    if (type != DIR_TYPE)
        return;

    // 0. add a new entry in current node's directory list and syn back to device
    addDirectoryEntryAndSync(node -> inumber, name);

    // 1. increment nlinks field by one for the newly linked node
    node -> nlinks += 1;
    node -> syncBackToDevice();
}

Node* Node::newNode(const char* name, uint32_t type) {
	// precondition: current node is a directory node; type is either a file type or a directory type
    if (this -> type != DIR_TYPE) return nullptr;
    if (type != DIR_TYPE && type != FILE_TYPE) Debug::panic("Invalid file type. Must be either DIR_TYPE (1) or FILE_TYPE (2).");

	// 0. allocate an empty i-node from fs
	uint32_t emptyinumber = fs -> allocateAnEmptyinode();
    // 1. write back to disk on the corresponding i-node position with attributes of an empty type (file or directory)
    fs -> updateinode(emptyinumber, type, 1, 0, 0, 0);
    // 2. add a directory entry for this newly created file in this current DIR_TYPE i-node
    addDirectoryEntryAndSync(emptyinumber, name);
    // 3. create and return an in-memory representation of this newly allocated empty file_type i-node
    return Node::get(fs, emptyinumber);
}

Node* Node::newFile(const char* name) {
    return newNode(name, FILE_TYPE);
}

Node* Node::newDirectory(const char* name) {
    return newNode(name, DIR_TYPE);
}


void Node::dump(const char* name) {
// #if 0
    uint32_t type = getType();
    switch (type) {
    case DIR_TYPE:
        Debug::printf("*** 0 directory:%s(%d)\n",name,getLinks());
        {
            uint32_t sz = getSize();
            uint32_t offset = 0;

            while (offset < sz) {
                uint32_t ichild;
                readAll(offset,&ichild,4);
                offset += 4;
                uint32_t len;
                readAll(offset,&len,4);
                offset += 4;
                char* ptr = (char*) malloc(len+1);
                readAll(offset,ptr,len);
                offset += len;
                ptr[len] = 0;              
                
                Node* child = Node::get(fs,ichild);
                child->dump(ptr);
                free(ptr);
            }
        }
        break;
    case FILE_TYPE:
        Debug::printf("*** 0 file:%s(%d,%d)\n",name,getLinks(),getSize());
        break;
    default:
         Debug::panic("unknown i-node type %d\n",type);
    }
// #endif
}

// helper method 0: write back current node information to device
void Node::syncBackToDevice() {
	fs -> updateinode(inumber, type, nlinks, size, directBlockNumber, indirectBlockNumber);
}

// helper method 1: add an entry in current directory i-node's data
void Node::addDirectoryEntryAndSync(uint32_t inumber, const char* name) {
    // precondition: current node must be a directory node
    if (type != DIR_TYPE) 
        Debug::panic("Can only add an entry in a DIR_TYPE node. A FILE_TYPE node called addEntry.");

    int nameLen = nameLength(name);
    if (size + 8 + nameLen > BobFS::MAX_NODE_SIZE)
    	Debug::panic("Current directory is full. Cannot add any more entries in it!");

    // allocate blocks for these extra 8 + nameLen bytes, if needed
    allocateBlocksFromBytesNeeded(8 + nameLen);
    // append one more directory entry to the current directory node
    writeAll(size, &inumber, 4);
    writeAll(size, &nameLen, 4);
    writeAll(size, name, nameLen);
}

// helper method 2: find the byte address of offset in file
// recall that offset is address within the file. we want to find the byte address on device that stores the data at offset.
uint32_t Node::offsetInFile2ByteAddrOnDevice(uint32_t offset) {
    uint32_t bn = -1; // block number of block that contains the data at offset
    if (offset < BobFS::BLOCK_SIZE) 
        bn = directBlockNumber;
    else {
        fs -> device -> readAll(indirectBlockNumber * BobFS::BLOCK_SIZE + (offset - BobFS::BLOCK_SIZE) / BobFS::BLOCK_SIZE * 4, &bn, 4);
    }
    return bn * BobFS::BLOCK_SIZE + offset % BobFS::BLOCK_SIZE;
}

// helper method 3: allocate new block(s) for this node because we are going to write some data to this node
// by invoking method like newFile if this node is a directory node, or, writeAll if this node is a file node
// bytesNeededAfterSize is the number of bytes expected to be added after the current file (e.g. add an directory
// entry will need extra 4 + 4 + nameLen bytes appended to this data of current directory node, so, in this case
// bytesNeededAfterSize should be 8 + nameLen).
void Node::allocateBlocksFromBytesNeeded(uint32_t bytesNeededAfterSize) {
	if (bytesNeededAfterSize == 0)
		return;

	if (directBlockNumber == 0) {
		// no matter what bytesNeededAfterSize is, we always need direct block (potential more blocks later).
		uint32_t emptyBlockNumber = fs -> allocateAnEmptyBlock();
	    directBlockNumber = emptyBlockNumber;
	    syncBackToDevice();

	    // okay, we've accommodated BobFS::BLOCK_SIZE bytes, let's see do we need to continue
	    if (bytesNeededAfterSize <= BobFS::BLOCK_SIZE) return;
	    bytesNeededAfterSize -= BobFS::BLOCK_SIZE;
	} else {
		// otherwise, see if we can accomodate any
		if (BobFS::BLOCK_SIZE >= size && bytesNeededAfterSize <= BobFS::BLOCK_SIZE - size) return;
		bytesNeededAfterSize -= BobFS::BLOCK_SIZE >= size ? BobFS::BLOCK_SIZE - size : 0;
	}

	// if we reach this point, then we need some help from indrect block to accomodate bytesNeededAfterSize 
	if (indirectBlockNumber == 0) {
		uint32_t emptyBlockNumber = fs -> allocateAnEmptyBlock();
	    indirectBlockNumber = emptyBlockNumber;
	    syncBackToDevice();
	}
	
    // now, depending on how large bytesNeededAfterSize is, we are going to allocate and set more blocks in the indirect block
	uint32_t startIndex, endIndex;
	if (size <= BobFS::BLOCK_SIZE) {
		startIndex = 0;
		endIndex = (bytesNeededAfterSize - 1) / BobFS::BLOCK_SIZE + 1;
	} else {
		startIndex = (size - BobFS::BLOCK_SIZE - 1) / BobFS::BLOCK_SIZE + 1;
		endIndex = (size - BobFS::BLOCK_SIZE + bytesNeededAfterSize - 1) / BobFS::BLOCK_SIZE + 1;
	}

	for (; startIndex < endIndex; ++startIndex) {
		// startIndex is the index of the one pass the current block number in the indirect block (initialized to one pass the last block number)
		// endIndex is the index of one pass the final last block number that we need to accomodate those extra bytes in the indrect block
		uint32_t emptyBlockNumber = fs -> allocateAnEmptyBlock();
	    fs -> device -> writeAll(indirectBlockNumber * BobFS::BLOCK_SIZE + startIndex * 4, &emptyBlockNumber, 4);
	}
}


///////////
// BobFS //
///////////

BobFS::BobFS(Ide* device) {
    this -> device = device;
    rootinumber = findRootinumberFromDevice(device);
    device -> readAll(BLOCK_SIZE, blocksBitMap, BLOCK_SIZE);
    device -> readAll(BLOCK_SIZE * 2, inodesBitMap, BLOCK_SIZE);
}

BobFS::~BobFS() {}

Node* BobFS::root(BobFS* fs) {
    return Node::get(fs, fs -> rootinumber);
}

BobFS* BobFS::mount(Ide* device) {
    return new BobFS(device);
}

BobFS* BobFS::mkfs(Ide* device) {
	// set up super block: magic number + root i-number
	device -> writeAll(0, zero_1024, BLOCK_SIZE);
	device -> writeAll(0, "BOBFS439", 8);

	uint32_t rootinumber = 15;
	device -> writeAll(8, &rootinumber, 4);

	// set up data block bitmap (all 0's)
	device -> writeAll(BLOCK_SIZE, zero_1024, BLOCK_SIZE);

	// set up i-nodes bitmap (all 0's except one 1 for the root i-node)
	device -> writeAll(BLOCK_SIZE * 2, zero_1024, BLOCK_SIZE);
	uint8_t firstByteIninodesBitMap = 0x1;
	device -> writeAll(BLOCK_SIZE * 2 + 1, &firstByteIninodesBitMap, 1);

	// set up i-nodes table (just need to set up the root i-node)
	uint32_t rootinode[4] = {0x10001, 0x0, 0x0, 0x0};
	device -> writeAll(BLOCK_SIZE * 3 + rootinumber * 16, &rootinode, 16);

	return new BobFS(device);
}


// helper method 0: write blocksBitMap to device (should be invoked if blockBitMap is modified)
void BobFS::writeBackBlocksBitMap() {
    device -> writeAll(1024, blocksBitMap, 1024);
}

// helper method 1: wrtie inodesBitMap to device (should be invoked if inodesBitMap is modified)
void BobFS::writeBackinodesBitMap() {
    device -> writeAll(1024 * 2, inodesBitMap, 1024);
}

// helper method 2: update blocksBitMap because block blockNumber has been allocated (if taken) or freed (if not taken)
//                  and write the changed blocksBitMap back to device.
void BobFS::updateblocksBitMap(uint32_t blockNumber, bool taken) {
    blockNumber -= 131;
    uint32_t i = blockNumber / 8;
    uint32_t j = blockNumber % 8;
    if (taken)
        // set the corresponding bit in inodesBitMap to 1, indicating that i-node has been taken.
        blocksBitMap[i] = blocksBitMap[i] | (0x80 >> j);
    else 
        // set the corresponding bit in inodesBitMap to 0, indicating that i-node has been taken.
        blocksBitMap[i] = blocksBitMap[i] & ~(0x80 >> j);
    writeBackBlocksBitMap();
}

// helper method 3: update inodesBitMap because i-node inumber has been taken (if taken) or freed (if not taken)
//                  and write the changed inodesBitMap back to device
void BobFS::updateinodesBitMap(uint32_t inumber, bool taken) {
    uint32_t i = inumber / 8;
    uint32_t j = inumber % 8;
    if (taken)
        // set the corresponding bit in inodesBitMap to 1, indicating that i-node has been taken.
        inodesBitMap[i] = inodesBitMap[i] | (0x80 >> j);
    else 
        // set the corresponding bit in inodesBitMap to 0, indicating that i-node has been taken.
        inodesBitMap[i] = inodesBitMap[i] & ~(0x80 >> j);
    writeBackinodesBitMap();
}

// helper method 4: find the next empty block number. Return -1 if all blocks are taken
int BobFS::nextEmptyBlockNumber() {
    int emptyBlockNumber = -1;
    for (int i = 0; i < 1024; ++i) {
        char nextByte = blocksBitMap[i];
        char mostSignificantBitIsOne = 0x80;
        int posOfFirstZeroInNextByte = -1;
        for (int j = 0; j < 8; ++j) {
            if (!((nextByte<<j) & mostSignificantBitIsOne)) {
                posOfFirstZeroInNextByte = j;
                break;
            }
        }
        if (posOfFirstZeroInNextByte != -1) {
            emptyBlockNumber = 8 * i + posOfFirstZeroInNextByte;
            break;
        }
    }

    if (emptyBlockNumber == -1)
        return -1;
    else
        return emptyBlockNumber + 131;
}

// helper method 5: find the next empty i-node number. Return -1 if there is not empty i-node left.
int BobFS::nextEmptyinumber() {
    // Debug::printf("nextEmptyinumber()\n");
    int emptyinumber = -1;
    for (int i = 0; i < 1024; ++i) {
        char nextByte = inodesBitMap[i];
        int posOfFirstZeroInNextByte = -1;
        for (int j = 0; j < 8; ++j) {
            if ((nextByte << j & 0x80) == 0) {
                posOfFirstZeroInNextByte = j;
                break;
            }
        }
        if (posOfFirstZeroInNextByte != -1) {
            emptyinumber = 8 * i + posOfFirstZeroInNextByte;
            break;
        }
    }
    return emptyinumber;
}

// helper method 6: update an i-node
void BobFS::updateinode(uint32_t inumber, uint16_t type, uint16_t nlinks, uint32_t size, uint32_t direct, uint32_t indirect) {
    uint32_t inodeStart = 3 * 1024 + 16 * inumber;
    // write type
    device -> writeAll(inodeStart, &type, 2);
    // write nlinks
    device -> writeAll(inodeStart + 2, &nlinks, 2);   
    // write size
    device -> writeAll(inodeStart + 4, &size, 4);
    // write direct block number
    device -> writeAll(inodeStart + 8, &direct, 4);
    // write indirect block number
    device -> writeAll(inodeStart + 12, &indirect, 4);
}

// helper method 7: allocate one empty free block and return the block number
uint32_t BobFS::allocateAnEmptyBlock() {
    int result = nextEmptyBlockNumber();
    if (result < 0) Debug::panic("Disk is full. This new entry requires a new block and cannot find a new empty block!");
    updateblocksBitMap(result, true);
    return result;
}

// helper method 8: allocate one empty i-node and return the i-node number
uint32_t BobFS::allocateAnEmptyinode() {
    int result = nextEmptyinumber();
    if (result < 0) Debug::panic("Disk is full. Do not have any empty inodes.\n");
    updateinodesBitMap(result, true);
    return result;
}
