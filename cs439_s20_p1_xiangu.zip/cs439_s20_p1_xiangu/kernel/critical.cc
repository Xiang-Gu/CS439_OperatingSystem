#include "critical.h"
#include "atomic.h"

SpinLock spinlock;

void critical_begin() {
	spinlock.lock();
}

void critical_end() {
	spinlock.unlock();
}
