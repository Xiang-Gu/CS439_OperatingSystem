/* 
Same structure as provided t0.cc but different content
in the critical section. In the critical section of this
test, we will print out number 0 through 4 one at a line.
*/

#include "debug.h"
#include "config.h"
#include "smp.h"
#include "critical.h"

volatile bool done[MAX_PROCS];
volatile int counters[MAX_PROCS];

void kernelMain() {
    critical_begin();
    for (int i = 0; i < 5; ++i){
		Debug::printf("*** ");
        Debug::printf("%d", i);
        Debug::printf("\n");
    }
	critical_end();
	
	done[SMP::me()] = true;
    if (SMP::me() == 2) {
        for (unsigned i=0; i<kConfig.totalProcs; i++) {
            while (!done[i]);
        }
        Debug::shutdown();
    }
	else {
        while(true) asm volatile("hlt");
    }
}
