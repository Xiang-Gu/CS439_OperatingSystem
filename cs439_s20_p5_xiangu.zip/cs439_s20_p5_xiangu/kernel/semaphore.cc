#include "semaphore.h"
#include "debug.h"

void block(ISL* lock) {
	// get the next TCB from readyQ. if it's null or if it's not truly ready, create an "idle" TCB and context switch to it.
	TCB* nextTCBToRun = readyQ.remove();
	if (nextTCBToRun != nullptr && nextTCBToRun -> save_area[5] == 0) {
		readyQ.add(nextTCBToRun);
		nextTCBToRun = nullptr;
	}
	if (nextTCBToRun == nullptr) {
		nextTCBToRun = new TCBImpl([] {}); // an idle thread with an empty work
		// Debug::printf("idea thread %#x is created\n", nextTCBToRun);
	}
    
    // lazy initialize the stack of TCB when it's switched in for the first time
	initTCB(nextTCBToRun);

	TCB* blockedTCB = actives[SMP::me()];
    // update active to nextTCBToRun although we're momentarily lying and cover it up immedately in the next line
	actives[SMP::me()] = nextTCBToRun;

	// "pass the baton" of unlocking isl to the about-to-run thread
	nextTCBToRun -> save_area[6] = (uint32_t) lock;

	// Debug::printf("in block(), %#x will context switch to %#x\n", blockedTCB, nextTCBToRun);
	
	contextSwitch(blockedTCB -> save_area, nextTCBToRun -> save_area);
	
	// one of the three entries when a TCB is switched back to a core.
    // clear up dynamically allocated memory for other previously stopped threads
    clearPreviouslyStoppedTCB();

    // if the previous thread performed context switch because it was blocked in Semaphore::down(), please it unlock the ISL.
    // (you asked for this before too so it's time to give back!)
	unlockISLOfPreviouslyBlockedTCB();
}

// Semaphore::Semaphore(uint32_t count) {
//     MISSING();
// }

// void Semaphore::up(void) {
//     MISSING();
// }

// void Semaphore::down(void) {
//     MISSING();
// }
