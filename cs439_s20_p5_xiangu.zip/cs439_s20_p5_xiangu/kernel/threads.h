#ifndef _threads_h_
#define _threads_h_

#include "atomic.h"
#include "queue.h"
#include "heap.h"
#include "debug.h"
#include "smp.h"

extern void threadsInit();
extern void stop();
extern void yield();
extern void thread_entry();


// an abstract class for thread control block, which is the class
// to encapsulate everything in a thread
class TCB {
public:
	// 5 registers need to be saved by the thread
	// %ebx, %esp, %ebp,  %esi, %edi, ready_flag, isl_pointer
    // first five are the "context" of this thread
    // ready_flag is 0 or 1, representing whether it's truly ready to be pulled off from the readyQ
    // isl_pointer is nullptr or ISL*. Used for Semaphore::down(). If it's not nullptr, it means we need to unlock this ISL for the previous thread who called down() and got blocked. 
	uint32_t save_area[7]; 
	TCB* next = nullptr;
    uint32_t* stack = nullptr;

	virtual void do_your_thing() = 0;
    virtual ~TCB() {}
};

// a templated class that inherits the TCB base (abstrct) class
template <typename T>
class TCBImpl : public TCB {
    T work;

public:
    TCBImpl(T work): work(work) {
        save_area[5] = 1;
        save_area[6] = (uint32_t) nullptr;
    }

    void do_your_thing() {
       work();
    }

    ~TCBImpl() {
        delete stack;
    }
};

// another child class that inherits the TCB base (abstract) class
// but it's used to represent the very first threads running on the
// four cores. The four stacks for each core are effectively those
// four fakeTCB's stack so we don't dynamically allocate any memory them.
class FakeTCB : public TCB {
public:
    void do_your_thing() {
        Debug::printf("Error!!! do_your_thing is called on a FakeTCB object!\n");
    }
};


extern Queue<TCB> readyQ;
extern void initTCB(TCB* nextTCBToRun);
extern void clearPreviouslyStoppedTCB();
extern void unlockISLOfPreviouslyBlockedTCB();
extern "C" void contextSwitch(uint32_t*,uint32_t*);
extern TCB** actives;
extern TCB** stoppedTCBs;

template <typename T>
void thread(T work) {
    // work is a callable object that takes no argument
    // so we create a new TCB object with work.
    TCBImpl<T>* tcb = new TCBImpl<T>(work);

    // Debug::printf("thread %#x has been created\n", tcb);

    readyQ.add(tcb);
}

#endif
