#ifndef _carr_h_
#define _carr_h_

#include "debug.h"
#include "semaphore.h"

template <int N, typename T>
class BoundedBuffer {
	// a nested class that implements a circular array. must be used together with BoundedBuffer semaphore guards to be safe.
	class circularArray {
		T arr[N];
		int nextIn = 0;
		int nextOut = 0;

	public:
		void append(T t) {
			arr[nextIn] = t;
			nextIn = (nextIn + 1) % N;
		}

		T pop() {
			T result = arr[nextOut];
			nextOut = (nextOut + 1) % N;
			return result;
		}
	};

	circularArray carr;
	Semaphore mutex = 1;
	Semaphore nEmpty = N;
	Semaphore nFill = 0;

public:
    BoundedBuffer() = default;

    void put(T t) {
        nEmpty.down();
        mutex.down();
        carr.append(t);
        mutex.up();
        nFill.up();
    }

    T get() {
        nFill.down();
        mutex.down();
        T result = carr.pop();
        mutex.up();
        nEmpty.up();
        return result;
    }    
};

#endif
