#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_

#include "stdint.h"
#include "queue.h"
#include "threads.h"


extern void block(ISL*);


class Semaphore {
	uint32_t cnt;
	Queue<TCB> waitingQ;
	ISL lock;

public:
	Semaphore(const uint32_t count) : cnt (count) {}

	void down() {
		// Debug::printf("%#x Semaphore::down()\n", actives[SMP::me()]);
		bool wasDisabled = lock.lock();
		// Debug::printf("%#x get the ISL lock for Semaphore::down()\n", actives[SMP::me()]);
		if (cnt == 0) {
			// Debug::printf("opps, Semaphore not available, thread %#x is blocked\n", actives[SMP::me()]);
			// 1. block this thread by adding the TCB to the waitingQ
			waitingQ.add(actives[SMP::me()]);
			// 2. perform a context switch
			block(&lock);
			enable(wasDisabled);
		} else {
			// Debug::printf("congrats, Semaphore available, thread %#x decrement the counter\n", actives[SMP::me()]);
			cnt--;
			lock.unlock(wasDisabled);
			// Debug::printf("%#x release ISL lock for Semaphore::down()\n", actives[SMP::me()]);
		}
	}

	void up() {
		// Debug::printf("%#x Semaphore::up()\n", actives[SMP::me()]);
		bool wasDisabled = lock.lock();
		// Debug::printf("%#x get the ISL lock for Semaphore::up()!\n", actives[SMP::me()]);
		TCB* nextTCBTOWakeUp = waitingQ.remove();


		// simple case: jf waitingQ is empty, increment the counter
		if (nextTCBTOWakeUp == nullptr) {
			cnt++;
			// Debug::printf("no thread in the waitingQ hence ++cnt.\n");
		} else {
			// otherwise: "quietly" wake up that TCB by putting it into the readyQ
			readyQ.add(nextTCBTOWakeUp);
			// Debug::printf("%#x wake up thread %#x by putting it to readyQ.\n",actives[SMP::me()], nextTCBTOWakeUp);
		}

		// Debug::printf("%#x release the ISL lock for Semaphore::up()!\n", actives[SMP::me()]);
		lock.unlock(wasDisabled);
		return;	
	}
};





#endif

