#include "machine.h"

bool disable() {
	// get the previous interrupt flag
	bool wasDisabled  = (getFlags() & 0x200) == 0;
	// clear the interrupt flag
	cli();
	return wasDisabled;
}

void enable(bool wasDisabled) {
	// set interrupt flag only when it was previously set
	if (!wasDisabled) {
		sti();
	}
}