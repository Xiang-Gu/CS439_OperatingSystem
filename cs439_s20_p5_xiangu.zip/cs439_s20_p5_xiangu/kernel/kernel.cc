#include "debug.h"
#include "threads.h"
#include "semaphore.h"
#include "barrier.h"

/*
This is test about semaphore and Barrier where I used a semaphore as a mutex and Barrier to syn the whole program to make sure every thread finishes the critical section the mutex is guarding.
*/

/* Called by one CPU */
void kernelMain(void) {
    auto sem = new Semaphore(1);
    auto bar = new Barrier(100);

    for (int j = 0; j < 99; ++j)
        thread([sem, bar, j] {
            sem -> down();
            Debug::printf("*** ");
            for (int i = 0; i < 10; ++i)
                Debug::printf("%d", i);
            Debug::printf("\n");
            sem -> up();

            bar -> sync();
        });

    sem -> down();
    Debug::printf("*** ");
    for (int i = 0; i < 10; ++i)
        Debug::printf("%d", i);
    Debug::printf("\n");
    sem -> up();

    bar -> sync();
    Debug::printf("*** all threads have arrived! Main thread passed the Barrier!\n");
}
