#ifndef _queue_h_
#define _queue_h_

#include "atomic.h"

template <typename T>
class Queue {
    T* first = nullptr;
    T* last = nullptr;
    ISL lock;
public:
    Queue() : first(nullptr), last(nullptr), lock() {}

    void add(T* t) {
        bool wasDisabled = lock.lock();
        t->next = nullptr;
        if (first == nullptr) {
            first = t;
        } else {
            last->next = t;
        }
        last = t;
        lock.unlock(wasDisabled);
    }

    void addFront(T* t) {
        bool wasDisabled = lock.lock();
        t->next = first;
        first = t;
        if (last == nullptr) last = first;
        lock.unlock(wasDisabled);
    }

    T* remove() {
        bool wasDisabled = lock.lock();
        if (first == nullptr) {
            lock.unlock(wasDisabled);
            return nullptr;
        }
        auto it = first;
        first = it->next;
        if (first == nullptr) {
            last = nullptr;
        }
        lock.unlock(wasDisabled);
        return it;
    }
};

#endif
