#ifndef _threads_h_
#define _threads_h_

#include "atomic.h"
#include "queue.h"
#include "heap.h"
#include "vmm.h"
#include "debug.h"
#include "config.h"
#include "mutex.h"
#include "smp.h"

extern void threadsInit();
extern uint32_t globalCR3ForIdentityMapping;

// Base class for Thread
class Thread {
public:
    Thread* next = nullptr;
    uint32_t ebx;
    uint32_t esp;
    uint32_t ebp;
    uint32_t esi;
    uint32_t edi;
    uint32_t leaveMeAlone = 0;
    uint32_t cr3 = 0;
    virtual void start() = 0;
    void copyIdentityMapping();
    Thread();
    virtual ~Thread();
};

// Derived class from Thread, used for those initial four threads at four cores
class InitialThread : public Thread {
public:
    InitialThread() { }
    virtual void start() override {
         Debug::printf("*** should never happen\n");
    }
};

// Derived, templated class from Thread, used for user-defined threads
template <typename T>
class ThreadImpl : public Thread {
    T work;
public:
    long stack[2048];

    virtual void start() override {
        vmm_on(cr3);
        work();
    }

    ThreadImpl(T work) : work(work) {}
    virtual ~ThreadImpl() {
    }
};


extern void stop();
extern void entry();
extern void yield();
extern void block(Thread*);
extern void stop();
extern Thread* active();
extern void schedule(Thread* t);
extern Thread* doNotDisturb();
extern void reaper();

template <typename T>
void thread(T work) {
    // reaper();
    auto thread = new ThreadImpl<T>(work);
    long *topOfStack = &thread->stack[2045];
    //if ((((unsigned long) topOfStack) % 16) == 8) topOfStack --;
    topOfStack[0] = 0x200;       // sti
    topOfStack[1] = 0;           // cr2
    topOfStack[2] = (long)entry;
    thread->esp = (long) topOfStack;
    schedule(thread);
}

class Disable {
    bool was;
public:
    Disable() : was(disable()) {}
    ~Disable() { enable(was); }
};

#endif
