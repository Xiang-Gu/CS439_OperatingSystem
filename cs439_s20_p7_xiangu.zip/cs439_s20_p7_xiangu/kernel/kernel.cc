#include "debug.h"
#include "future.h"
#include "threads.h"

//IMPORTANT: MAKE SURE THAT YOU PATCH THE REAPER BEFORE TRYING TO RUN THIS
//THE PATCH CODE IS ON PIAZZA: https://piazza.com/class/k5n04513lw248b?cid=1225

// this test case tests two things:
// - are used page tables cleaned up when a thread stops?
// - does the kernel panic on an access to nullptr?
namespace TestCase {
    void assertTrue(bool condition) {
        if(!condition) {
            Debug::panic("*** assertion failed!\n");
        }
    }

    //makes sure that a pointer is initally zero and can be written to
    void checkPtr(uint32_t *ptr) {
        assertTrue(*ptr == 0);
        
        *ptr = (uint32_t) ptr;
        
        assertTrue(*ptr == (uint32_t)ptr);
    }
};

void kernelMain(void) {
    //we have 128 MB of physical available
    //that means 32,768 allocations will fill it up
    //I make each thread use 2048+1 pages so that an implementation will run out
    //if it does not clean up stopped threads' private regions
    
    for(int i = 0; i < 16; i++){
        volatile bool done = false;
        thread([&done] {
            uint32_t *base = (uint32_t *) 0x80000000;
            
            for(int j = 0; j < 2049; j++){
                TestCase::checkPtr(base + j * 0x1000);
            }
            
            done = true;
        });

        while(!done);
        Debug::printf("*** Thread %d finished\n", i);
    }

    Debug::printf("*** Success!\n");

    uint32_t *bad = 0; //null pointer
    
    TestCase::checkPtr(bad); //this function should cause the kernel to panic

    Debug::printf("*** This should never happen\n");

}

