#include "debug.h"
#include "smp.h"
#include "threads.h"
#include "vmm.h"

void Thread::copyIdentityMapping() {
	for (uint32_t i = 0; i <= kConfig.memSize / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE); ++i) {
		*(((uint32_t*) cr3) + i) = *(((uint32_t*) globalCR3ForIdentityMapping) + i);
	}

    // of course, don't forget to identity map the kConfig.ioAPIC and kconfig.localAPIC
    // remember they are in the same page table!
    uint32_t i = kConfig.ioAPIC / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE);
	*(((uint32_t*) cr3) + i) = *(((uint32_t*) globalCR3ForIdentityMapping) + i);
}


Thread::Thread() {
	// allocate page directory (each thread has its own page directory)
    cr3 = VMM::alloc();

    // copy pde's from globalCR3ForIdentityMapping
    copyIdentityMapping();

    // you might wonder why don't we also copy pde's from globalCR3ForSharedMemory here.
    // well, yes we can. But it's not necessary. We leave the work to the page fault handler
}

Thread::~Thread() {
	// what should be done in the destructor of the base class Thread?
	// 1. free the page directory
	// 2. free all the page tables in the thread-private range
	uint32_t start = 0x80000000 / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE);
	uint32_t end = 0xf0000000 / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE);
	uint32_t* pd = (uint32_t*) cr3;
	for (uint32_t i = start; i < end; ++i) {
		// if pde is present, then go into the page table
		if ((*(pd + i) & 1) == 1) {
			uint32_t* pt = (uint32_t*) (*(pd + i) & 0xFFFFF000);
			// free each present pte
			for (uint32_t j = 0; j < 1024; ++j) {
				if ((*(pt +j) & 1) == 1) {
					VMM::free(*(pt + j) & 0xFFFFF000);
				}
			}
			// free the page table itself
			VMM::free((uint32_t) pt);
		}
	}
	// free the page directory itself
	VMM::free(cr3);
}



Queue<Thread> readyQ;
Queue<Thread> zombieQ;
Thread** activeThreads;

void reaper() {
    Thread* firstAlone = nullptr;
    while(true) {
        auto th = zombieQ.remove();
        if (th == nullptr) return;
        if (th->leaveMeAlone) {
            if (th == firstAlone) {
                zombieQ.add(th);
                return;
            }
            if (firstAlone == nullptr) firstAlone = th;
            zombieQ.add(th);
        } else {
            delete th;
        }
    }
}

void threadsInit() {
    activeThreads = new Thread*[kConfig.totalProcs];
    for (uint32_t i=0; i<kConfig.totalProcs; i++) {
        activeThreads[i] = new InitialThread();
    }

    // The reaper
    thread([]() {
        while(true) {
            reaper();
            yield();
        }
    });
}


bool isDisabled() {
    uint32_t oldFlags = getFlags();
    return (oldFlags & 0x200) == 0;
}

bool disable() {
    bool wasDisabled = isDisabled();
    if (!wasDisabled)
        cli();
    return wasDisabled;
}

void enable(bool wasDisabled) {
    if (!wasDisabled)
        sti();
}

void schedule(Thread* t) {
    readyQ.add(t);
}

Thread* active() {
    Disable x;
    return activeThreads[SMP::me()];
}

void entry() {
    Thread* me = active();
    me->start();
    stop();
}

extern "C" void contextSwitch(uint32_t*,uint32_t*);

void block(Thread* me) {
again:
    auto next = readyQ.remove();

    if (next == me) {
        // It is possible for a thread to run into itself, can you see why?
        // block for something, get interrupted, the thing happens, get here
        me->leaveMeAlone = 0;
        return;
    }

    if (next == nullptr) {
    	// Debug::printf("empty readyQ, try to grab a thread to run AGAIN!\n");
    	goto again;
    }

    if (next->leaveMeAlone) {
        readyQ.add(next);
        goto again;
    }
    
    next->leaveMeAlone = 1;

    {
        Disable x;
        activeThreads[SMP::me()] = next;
    }
 

    vmm_on(active() -> cr3);
    contextSwitch(&me->ebx,&next->ebx);
    // set %cr3 to be my own cr3 to conclude the context switch.
    // You may ask that when we're setting cr3 using the following statement,
    // %cr3 still stores the cr3 of the previously running thread, meaning we
    // are using the wrong page directory. Fortunately, the following statement
    // will only access kernel/kernel heap part of memory, which is always
    // identity mapped throughout all threads. So, the following statement will still work!

}

void yield() {
    auto was = disable();
    auto me = activeThreads[SMP::me()];
    enable(was);
    if (me->leaveMeAlone) return;
    me->leaveMeAlone = 1;     // we check then we set with 
                              // interrupts enabled and no spin lock
                              // is this a race condition?
    readyQ.add(me);
    block(me);
}

void stop() {
    auto was = disable();
    auto me = activeThreads[SMP::me()];
    enable(was);
    me->leaveMeAlone = 1;
    zombieQ.add(me);
    block(me);
}
