#include "vmm.h"
#include "machine.h"
#include "idt.h"
#include "libk.h"
#include "mutex.h"
#include "config.h"
#include "threads.h"
#include "debug.h"


struct VMMNode {
    VMMNode* next;
};

struct VMMInfo {
    VMMNode *firstFree;
    uint32_t avail;
    uint32_t limit;
    Mutex lock {};
    Mutex sharedLock {};
};

static VMMInfo *info = nullptr;
uint32_t globalCR3ForIdentityMapping = 0; 
uint32_t globalCR3ForSharedMemory = 0;
// sharedMemoryLock is used to protect shared resource globalCR3ForSharedMemory.
// globalCR3ForIdentityMapping is also a shared resource -- being used for in Thread's constructor
// but it will only be read so no need to use locks to protect it.
Mutex sharedMemoryLock;

void VMM::init(uint32_t start, uint32_t size) {

    Debug::printf("| physical range 0x%x 0x%x\n",start,start+size);
    info = new VMMInfo;
    info->avail = start;
    info->limit = start + size;
    info->firstFree = nullptr;

    // register the page fault handler
    IDT::trap(14,(uint32_t)pageFaultHandler_,3);

    VMM::initGlobalCR3ForIdentityMapping();
    VMM::initGlobalCR3ForSharedMemory();

    sharedMemoryLock = Mutex();
}


uint32_t VMM::alloc() {
    uint32_t p = 0;

    info->lock.lock();

    if (info->firstFree != nullptr) {
        p = (uint32_t) info->firstFree;
        info->firstFree = info->firstFree->next;
    } else {
        if (info->avail == info->limit) {
            Debug::panic("no more frames");
        }
        p = info->avail;
        info->avail += FRAME_SIZE;
    }
    info->lock.unlock();

    bzero((void*)p,FRAME_SIZE);

    return p;
}

void VMM::free(uint32_t p) {

    info->lock.lock();

    VMMNode* n = (VMMNode*) p;    
    n->next = info->firstFree;
    info->firstFree = n;

    info->lock.unlock();

}

void VMM::initGlobalCR3ForIdentityMapping() {
    globalCR3ForIdentityMapping = VMM::alloc();
    uint32_t* pd = (uint32_t*) globalCR3ForIdentityMapping;
    // initialize identity mapping with globalCR3ForIdentityMapping
    for (uint32_t i = 0; i <= kConfig.memSize / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE); ++i) {
        // allocate a page table
        uint32_t addr = VMM::alloc();
        *(pd + i) = addr | 0b111;
        // fill in entries in this page table
        uint32_t* pt = (uint32_t*) addr;
        for (uint32_t j = 0; j < VMM::FRAME_SIZE / 4; ++j) {
            *(pt + j) = ((i * VMM::FRAME_SIZE / 4 + j) * VMM::FRAME_SIZE) | 0b111;
        }
    }

    // of course, do not forget to identity map the kConfig.ioAPIC and kconfig.localAPIC
    // uint32_t i1 = kConfig.ioAPIC / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE);
    uint32_t i1 = kConfig.ioAPIC >> 22 & 0x3FF;
    uint32_t addr = VMM::alloc();
    *(pd + i1) = addr | 0b111;
    uint32_t* pt = (uint32_t*) addr;
    // uint32_t j1 = (kConfig.ioAPIC / VMM::FRAME_SIZE) % (VMM::FRAME_SIZE / 4);
    uint32_t j1 = kConfig.ioAPIC >> 12 & 0x3FF;
    *(pt + j1) = (kConfig.ioAPIC & 0xFFFFF000) | 0b111;

    // uint32_t i2 = kConfig.localAPIC / (VMM::FRAME_SIZE / 4 * VMM::FRAME_SIZE);
    uint32_t i2 = kConfig.localAPIC >> 22 & 0x3FF;
    if (i2 != i1) Debug::panic("localAPIC offset in page directory is not the same as ioAPIC.");
    if (((*(pd + i2)) & 0xFFFFF000) != addr) Debug::panic("something is wrong with the pde because it != addr.");
    // pt = (uint32_t*) ((*(pd + i2)) & 0xFFFFF000); 
    
    // uint32_t j2 = (kConfig.localAPIC / VMM::FRAME_SIZE) % (VMM::FRAME_SIZE / 4);
    uint32_t j2 = kConfig.localAPIC >> 12 & 0x3FF;
    if (j1 == j2) Debug::panic("kConfig.ioAPIC is located within the same page as kConfig.localAPIC. Your assumption that they are not is wrong. Recheck your math and the program");
    *(pt + j2) = (kConfig.localAPIC & 0xFFFFF000) | 0b111;
}

void VMM::initGlobalCR3ForSharedMemory() {
    globalCR3ForSharedMemory = VMM::alloc();
}


// allocate a frame to map va to by modifying the tree-structure.
// possibly do nothing if a frame has been allocated previously.
// (shouldn't be used in identity mapping)
void VMM::map(uint32_t cr3, uint32_t va) {
    // precondition: cr3 in [0x00200000, kConfig.memSize) 
    if (cr3 < 0x00200000 || cr3 >= kConfig.memSize){
        Debug::printf("cr3 points to a frame in an invalid address. expected range [0x00200000, 0x%x], cr3 = 0x%x", kConfig.memSize, cr3);
        Debug::panic("");
    }

    uint32_t* pd = (uint32_t*) cr3;
    uint32_t pde = *(pd + (va >> 22 & 0x3FF));

    if ((pde & 0b111) != 0b111) {
        // a frame needed for this pde
        uint32_t addr = VMM::alloc();
        if (addr == 0) 
            Debug::panic("no more frames when trying to allocate one for the PDE as page table in map(va).");
        *(pd + (va >> 22 & 0x3FF)) = addr | 0b111;
        pde = *(pd + (va >> 22 & 0x3FF));
    }

    uint32_t* pt = (uint32_t*) (pde & 0xFFFFF000);
    uint32_t pte = *(pt + (va >> 12 & 0x3FF));

    if ((pte & 0b111) != 0b111) {
        // a frame needed for this pte
        uint32_t addr = VMM::alloc();
        if (addr == 0) 
            Debug::panic("no more frames when trying to allocate one for the PTE as the actual frame in map(va).");
        *(pt + (va >> 12 & 0x3FF)) = addr | 0b111;
    }
}

extern "C" void vmm_pageFault(uintptr_t va, uintptr_t *saveState) {
    // Debug::printf("| page fault @ %x\n", va);
    if (va < 0x1000) {
        Debug::panic("unmapped virtual address, panic!");
    } else if (va < 0x200000) {
        Debug::panic("should not page fault at this address because this is the range which should have been identity mapped!");
    } else if (va < 0x80000000) {
        Debug::panic("try to access a virtual address range which causes undefied behavior. Panic!");
    } else if (va < 0xf0000000) {
        // thread private
        VMM::map(active()->cr3, va);
    } else {
        // thread-shared
        sharedMemoryLock.lock();

        // reflect the change on the global page directory for shared memory, which may or may not has this mapping
        VMM::map(globalCR3ForSharedMemory, va);

        // copy that particular pde from global page directory for shared memory to my own page directory.
        // (So this is a very lazy way of implementing shared memory)
        uint32_t* globalpd = (uint32_t*) globalCR3ForSharedMemory;
        uint32_t* pd = (uint32_t*) (active() -> cr3);

        if ((va >> 22 & 0x3FF) != (kConfig.ioAPIC >> 22 & 0x3FF)) {
             // simply copy the globalCR3ForSharedMemory's pde
            *(pd + (va >> 22 & 0x3FF)) = *(globalpd + (va >> 22 & 0x3FF));
        } else {
            // copy globalCR3ForSharedMemory's pte. why? because we don't want to ruin our identity mapping
            uint32_t* globalpt = (uint32_t*) (*(globalpd + (va >> 22 & 0x3FF)) & 0xFFFFF000); 
            uint32_t* pt = (uint32_t*) (*(pd + (va >> 22 & 0x3FF)) & 0xFFFFF000); 
            *(pt + (va >> 12 & 0x3FF)) = *(globalpt + (va >> 12 & 0x3FF));
        }
        sharedMemoryLock.unlock();
    }
}
