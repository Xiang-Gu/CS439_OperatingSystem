#ifndef _VMM_H_
#define _VMM_H_

#include "stdint.h"
#include "atomic.h"
#include "mutex.h"
#include "smp.h"


// The virtual memory interface
namespace VMM {
    constexpr uint32_t FRAME_SIZE = (1 << 12);

    // Called to initialize the available physical memory pool
    void init(uint32_t start, uint32_t size);

    /* allocate a frame
           nullptr -> no frames availabe
           always 4K aligned
           zero-filled
     */
    uint32_t alloc();

    /* free a frame */
    void free(uint32_t);





    void map(uint32_t, uint32_t);
    void initGlobalCR3ForSharedMemory();
    void initGlobalCR3ForIdentityMapping();
};

#endif
