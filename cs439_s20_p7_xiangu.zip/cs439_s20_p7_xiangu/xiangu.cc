#include "debug.h"
#include "threads.h"
#include "atomic.h"
#include "future.h"

/*
This test made sure some basic functionality is achieved:
    1. threads are isolated in the thread-private memory range;
    2. threads can communicate with each through thread-shared memory range.
*/

/* Called by one CPU */
void kernelMain(void) {
	/* thread-private test */
	Future<int> f1;

    uint32_t* privatePtr = (uint32_t*) 0x81111100;
    *privatePtr = 100;
    if (*privatePtr != 100) {
    	Debug::printf("*** you failed.\n");
    }

    thread([&f1] {
    	uint32_t* privatePtr = (uint32_t*) 0x81111100;
    	*privatePtr = 200;
    	if (*privatePtr != 200) {
    		Debug::printf("*** you failed.\n");
    	}
    	f1.set(*privatePtr);
    });

    int x = f1.get();
    if ((uint32_t) x == *privatePtr) {
    	Debug::printf("*** you failed.\n");
    }

    Debug::printf("*** you passed thread-private test.\n");

    /* thread-shared test */
    Future<int> f2;
    uint32_t* sharedPtr = (uint32_t*) 0xfabda0ce;
    *sharedPtr = 300;

    thread([&f2] {
    	uint32_t* sharedPtr = (uint32_t*) 0xfabda0ce;
    	if (*sharedPtr != 300) {
    		Debug::printf("*** you failed.\n");
    	}
    	*sharedPtr = 400;
    	f2.set(500);
    });

    int y = f2.get();
    if (y != 500 || *sharedPtr != 400) {
    	Debug::printf("*** you failed.\n");
    }

    Debug::printf("*** you passed thread-shared test.\n");

    Debug::printf("*** you passed the whole test.\n");
}

