#include "threads.h"
#include "atomic.h"
#include "debug.h"

// Whoops sorry about that
#include "semaphore.h"

/*
 * This test case covers a couple things:
 * 1. Are you efficiently sharing the identity map with all
 *    of your threads?
 * 2. Does each thread truly have a private area of memory?
 * 3. Does your shared area of memory work correctly?
 * 4. Can you handle the edge case where we write to an address in 
 *    shared memory which also happens to be part of the same PT
 *    as the APICs?
 * 5. Can your implementation handle many memory accesses (and page faults)
 *    by concurrent threads?
 *
 */

class MyBarrier{
	Atomic<uint32_t> counter;
	Semaphore s;
	public:
	explicit MyBarrier(uint32_t count) : counter(count), s(0) {}
	void sync() {
		int x = counter.add_fetch(-1);
		if(x > 0)
			s.down();
		s.up();
	}
};

void kernelMain(){

	/*
	 *        Test Suite #1
	 */

	Atomic<uint32_t> counter{0};
	static constexpr uint32_t NUM_THREADS1 = 80;
	static constexpr uint32_t SHARED_VAL1 = 0xfadf00d;
	static constexpr uint32_t SHARED_VAL2 = 0xf00f00;

	int* shared1 = (int*) 0xfeedbeef;
	int* shared2 = (int*) 0xfadebead;
	*shared1 = SHARED_VAL1;
	*shared2 = SHARED_VAL2;

	for(uint32_t i = 0; i < NUM_THREADS1; i++){
		thread([&counter, shared1, shared2]{
			int* p = (int*) 0xbeefcafe;
			if(*p != 0){
				Debug::panic("*** Hey! My memory wasn't zeroed out!\n");
			}
			*p = 0xbadc0de;
			if(*shared1 != SHARED_VAL1)
				Debug::panic("*** Hey! My memory isn't being shared near the APICs!\n");
			if(*shared2 != SHARED_VAL2)
				Debug::panic("*** Hey! My memory isn't being shared!\n");
			counter.fetch_add(1);
		});
	}

	while(counter.get() < NUM_THREADS1);
	Debug::printf("*** Passed many threads spawned test!\n");

	/*
	 *        Test Suite #2
	 */

	static constexpr uint32_t NUM_THREADS2 = 4;
	
	MyBarrier b{NUM_THREADS2};

	Atomic<uint32_t> num_done{0};

	for(uint32_t i = 1; i <= NUM_THREADS2; i++){
		thread([&b, &num_done, i]{
			int count = 1;
			for(uintptr_t addr = 0x80000000; addr < 0xa0000000; addr += ( 1 << 12) << 8){
				uint32_t* p = (uint32_t*) addr;
				*p = i * count++;
			}
			b.sync();
			count = 1;
			for(uintptr_t addr = 0x80000000; addr < 0xa0000000; addr += ( 1 << 12) << 8){
				uint32_t* p = (uint32_t*) addr;
				if(*p != i * count){
					Debug::panic("*** This memory isn't how I left it!\n");
				}
				count++;
			}
			num_done.fetch_add(1);
		});
	}

	while(num_done.get() < NUM_THREADS2);
	Debug::printf("*** Passed many concurrent accesses test\n");
}

