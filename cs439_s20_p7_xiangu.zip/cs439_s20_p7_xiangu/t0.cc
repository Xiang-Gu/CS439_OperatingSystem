#include "debug.h"
#include "future.h"
#include "threads.h"

void disp(int *ptr) {
     Debug::printf("*** mem[0x%x] = %d\n",ptr,*ptr);
}

void show(int v) {
     int* ptr = (int*) 0x80000000;
     int old = *ptr;
     disp(ptr);
     *ptr = old + v;
     disp(ptr);
}

/* Called by one CPU */
void kernelMain(void) {
     int x = 100;

     Future<int> f;

     show(1000);
     show(1000);

     int* q = (int*) 0xf0000000;
     *q = 42;

     thread([&f,x,q] {
         show(10);
         show(20);
         disp(q);
         *q = 666;
         f.set(x+1);
     });


     Debug::printf("*** x = %d, result = %d\n",x,f.get());

     show(100);
     show(200);
     disp(q);
     Debug::printf("%d\n",*q);

}

