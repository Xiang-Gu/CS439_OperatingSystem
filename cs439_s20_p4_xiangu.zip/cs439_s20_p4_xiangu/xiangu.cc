#include "debug.h"
#include "threads.h"
#include "atomic.h"

/*
This test stresses on the efficiency of stop() by spawning many many
threads in which stop() will immediately be called. If we use the provided 
bad implementation of stop() where we just call yield() indefinitely then 
the readyQ will soon become too crowded. At the same time, this kernelMain 
thread will try to do some work that requires a significant amount of cpu services.
If the readyQ is too crowded, then it will take a long long long time 
for this kernelMain thread to get that many services, causing a timeout on
the server.

On the other hand, if stop() correctly switch in the next thread in the 
readyQ *without* putting the old stopped thread back into the readyQ, all those
spawnned threads will soon be executed and cleared, and the readyQ will be
unoccupied, hence allowing the kernelMain to quickly be switched in and out
for numServiceForMainThread times before timeout.
*/


/* Called by one CPU */
void kernelMain(void) {
    int numSpawnedThreads = 100;
    int numServiceForMainThread = 1000;

    for (int i = 0; i < numSpawnedThreads; ++i) {
        thread([] () {
            stop();
        });
    }

    int counter = numServiceForMainThread;
    while (counter-- != 0) yield();

    Debug::printf("*** job successfully finished!\n");
}

