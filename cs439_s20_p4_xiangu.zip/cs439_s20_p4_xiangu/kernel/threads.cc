#include "debug.h"
#include "smp.h"
#include "threads.h"

extern "C" void contextSwitch(uint32_t*,uint32_t*);

Queue<TCB> readyQ;
TCB** actives;
TCB** stoppedTCBs; // points to the most recently stopped TCB so that whichever TCB that has just been switched in can help clear up the memory for this stopped thread

// initialize the stack of nextTCBToRun if this is the first time for nextTCBToRun to execute
void initTCB(TCB* nextTCBToRun) {
    if (nextTCBToRun -> stack == nullptr) {
        nextTCBToRun -> stack = (uint32_t*) malloc(2048 * 4); // each thread has its own stack
        nextTCBToRun -> stack[2047] = (uint32_t) thread_entry;
        nextTCBToRun -> save_area[1] = (uint32_t) &((nextTCBToRun -> stack)[2047]);
    }
}

// free memory allocated for previously stopped TCB on this core
void clearPreviouslyStoppedTCB() {
	if (stoppedTCBs[SMP::me()] != nullptr) {
		delete stoppedTCBs[SMP::me()];
		stoppedTCBs[SMP::me()] = nullptr;
	}
}

// thread entry when a TCBImpl is switched in from the readyQ for the first time.
void thread_entry() {
	// one of the two entries when a TCB is switched back to a core so clear up for the previous stopped TCB on this core, if any.
	clearPreviouslyStoppedTCB();
	actives[SMP::me()] -> do_your_thing();
	stop();
}

// called by core 0 in init.cc that creates four fake TCB and set up stoppedTCBs array.
void threadsInit() {
	actives = new TCB*[kConfig.totalProcs];
	stoppedTCBs = new TCB*[kConfig.totalProcs];

	for (uint32_t i = 0; i < kConfig.totalProcs; ++i) {
		actives[i] = new FakeTCB();
		stoppedTCBs[i] = nullptr;
	}
}

void yield() {
    // idea: perform a context swith b/t the current running TCB and the first TCB in readyQ
    
    auto nextTCBToRun = readyQ.remove();
    // if there is no TCB waiting to run, return so that the thread which called yield() can continue to run
    if (nextTCBToRun == nullptr) return;
    // if the next TCB to run is not truly ready, meaning the context switch isn't fully finished after it has been put into the readyQ,
    // then put it back to the end of the readyQ and return to the thread which called yield() so that it can continue to run.
    if (nextTCBToRun -> save_area[5] == 0) {
    	readyQ.add(nextTCBToRun);
    	return;
    }

    // lazy initialize the stack of TCB when it's switched in for the first time
	initTCB(nextTCBToRun);

    TCB* previousRunningTCB = actives[SMP::me()];
    // update active to nextTCBToRun although we're momentarily lying and cover it up immedately in the next line
	actives[SMP::me()] = nextTCBToRun;  

	// put current running to the end of the ready queue
	previousRunningTCB -> save_area[5] = 0;
	readyQ.add(previousRunningTCB);  
	contextSwitch(previousRunningTCB -> save_area, nextTCBToRun -> save_area);

	// one of the two entries when a TCB is switched back to a core.
	// clear up dynamically allocated memory for other previously stopped threads
	clearPreviouslyStoppedTCB();
}

// Try to pull off one TCB from the readyQ to context switch to.
void stop() {
	TCB* nextTCBToRun = nullptr;
	while (true) {
		nextTCBToRun = readyQ.remove();
		if (nextTCBToRun == nullptr) continue; 
		if (nextTCBToRun -> save_area[5] == 0) {
			readyQ.add(nextTCBToRun);
			continue;
		}
		break;
	}

    // lazy initialize the stack of TCB when it's switched in for the first time
	initTCB(nextTCBToRun);

	// update stoppedTCBs pointer
	TCB* stoppedTCB = actives[SMP::me()];
	stoppedTCBs[SMP::me()] = stoppedTCB;
    // update active to nextTCBToRun although we're momentarily lying and cover it up immedately in the next line
	actives[SMP::me()] = nextTCBToRun;  
 
	contextSwitch(stoppedTCB -> save_area, nextTCBToRun -> save_area);
	// Oblivion: nothing should be here because this thread is stopped and hence won't return anymore. 
}
